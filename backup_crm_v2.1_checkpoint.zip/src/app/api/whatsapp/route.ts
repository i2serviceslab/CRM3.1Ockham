import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';
import QRCode from 'qrcode';

const db = new PrismaClient();

// Global session state for Baileys Socket Engine
let globalSession = {
  status: 'DISCONNECTED', // DISCONNECTED, CONNECTING, CONNECTED
  phoneNumber: null as string | null,
  qrCode: null as string | null,
  botEnabled: true,
  lastActivity: new Date().toISOString(),
};

// Positive Silver Fun Facts in Pure English
const SILVER_FUN_FACTS = [
  "Did you know silver has the highest electrical and thermal conductivity of all elements on Earth, making it indispensable for solar technology and electric vehicles?",
  "Did you know Outcrop Silver's Santa Ana project in Colombia features high-grade epithermal veins with historical grades up to 4,000 g/t AgEq, making it one of the highest-grade primary silver deposits in Latin America?",
  "Did you know over 60% of global silver demand comes from industrial and medical applications due to its unique antibacterial and electrical properties?",
  "Did you know modern electric vehicles require approximately 20 grams of pure silver for their advanced battery and control systems?",
  "Did you know industrial demand for silver in renewable energy and photovoltaics is reaching historic record highs this decade?",
];

const STAGE_OPTIONS = [
  'Lead Prospect',
  'Interested - considering',
  'Meeting Scheduled',
  'Due Diligence',
  'Term Sheet',
  'Closed Investor',
];

async function getPendingRequests(whitelist: any[]) {
  const inboundMsgs = await db.whatsAppMessage.findMany({
    where: { direction: 'INBOUND' },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });

  const whitelistNumbers = new Set(
    whitelist.map((w: any) => (w.phoneNumber || '').replace(/\D/g, ''))
  );

  const pendingMap = new Map();

  for (const msg of inboundMsgs) {
    const digits = (msg.fromNumber || '').replace(/\D/g, '');
    if (!digits || digits === 'CRMBot') continue;

    const isWhitelisted = Array.from(whitelistNumbers).some(
      (wDigits: string) => wDigits && (digits.endsWith(wDigits) || wDigits.endsWith(digits) || digits === wDigits)
    );

    if (!isWhitelisted && !pendingMap.has(msg.fromNumber)) {
      let nameToUse = (msg as any).senderName || null;
      if (!nameToUse || nameToUse === 'Usuario WhatsApp' || nameToUse === 'WhatsApp User') {
        const namedMsg = await db.whatsAppMessage.findFirst({
          where: {
            fromNumber: msg.fromNumber,
          },
        });
        if (namedMsg && (namedMsg as any).senderName && (namedMsg as any).senderName !== 'Usuario WhatsApp' && (namedMsg as any).senderName !== 'WhatsApp User') {
          nameToUse = (namedMsg as any).senderName;
        }
      }

      pendingMap.set(msg.fromNumber, {
        fromNumber: msg.fromNumber,
        senderName: nameToUse || 'New Contact (WhatsApp)',
        lastMessage: msg.message,
        createdAt: msg.createdAt,
      });
    }
  }

  return Array.from(pendingMap.values());
}

export async function GET() {
  try {
    const dbSession = await db.whatsAppSession.findFirst({
      where: { id: 'default' },
    });

    if (dbSession) {
      globalSession.status = dbSession.status;
      globalSession.qrCode = dbSession.qrCode;
      globalSession.phoneNumber = dbSession.phoneNumber;
    }

    let whitelist = await db.whatsAppWhitelist.findMany({
      orderBy: { createdAt: 'desc' },
    });

    if (whitelist.length === 0) {
      await db.whatsAppWhitelist.createMany({
        data: [
          { phoneNumber: '+573012954278', name: 'Sara', role: 'Admin', isActive: true },
          { phoneNumber: '+573207116676', name: 'Nelson', role: 'Admin', isActive: true },
        ],
      });
      whitelist = await db.whatsAppWhitelist.findMany({
        orderBy: { createdAt: 'desc' },
      });
    }

    const pendingRequests = await getPendingRequests(whitelist);

    const messages = await db.whatsAppMessage.findMany({
      take: 25,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      success: true,
      session: globalSession,
      whitelist,
      pendingRequests,
      messages,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, message, phoneNumber, fromNumber, id, name, role, mediaUrl } = body;

    // 1. APPROVE PENDING ACCESS REQUEST WITH EDITABLE NAME
    if (action === 'APPROVE_REQUEST') {
      const targetPhone = (fromNumber || phoneNumber || '').trim();
      if (!targetPhone) {
        return NextResponse.json({ success: false, error: 'Phone number or identifier is required' }, { status: 400 });
      }

      const entry = await db.whatsAppWhitelist.upsert({
        where: { phoneNumber: targetPhone },
        update: { name: name || 'CRM Administrator', role: role || 'Admin', isActive: true },
        create: { phoneNumber: targetPhone, name: name || 'CRM Administrator', role: role || 'Admin', isActive: true },
      });

      const updatedWhitelist = await db.whatsAppWhitelist.findMany({
        orderBy: { createdAt: 'desc' },
      });

      const pendingRequests = await getPendingRequests(updatedWhitelist);

      return NextResponse.json({
        success: true,
        message: `Admin ${name || 'Administrator'} successfully authorized! Future messages will be processed instantly.`,
        entry,
        whitelist: updatedWhitelist,
        pendingRequests,
      });
    }

    if (action === 'REJECT_REQUEST') {
      const targetPhone = (fromNumber || phoneNumber || '').trim();
      if (targetPhone) {
        await db.whatsAppMessage.deleteMany({
          where: { fromNumber: targetPhone },
        });
      }

      const updatedWhitelist = await db.whatsAppWhitelist.findMany({
        orderBy: { createdAt: 'desc' },
      });

      const pendingRequests = await getPendingRequests(updatedWhitelist);

      return NextResponse.json({
        success: true,
        message: 'Request rejected and removed.',
        whitelist: updatedWhitelist,
        pendingRequests,
      });
    }

    // 2. Manage Whitelist Actions with Digit Normalization
    if (action === 'ADD_WHITELIST') {
      if (!phoneNumber) {
        return NextResponse.json({ success: false, error: 'Phone number is required' }, { status: 400 });
      }

      const cleanPhone = phoneNumber.trim();

      const entry = await db.whatsAppWhitelist.upsert({
        where: { phoneNumber: cleanPhone },
        update: { name: name || 'CRM Administrator', role: role || 'Admin', isActive: true },
        create: { phoneNumber: cleanPhone, name: name || 'CRM Administrator', role: role || 'Admin', isActive: true },
      });

      const updatedWhitelist = await db.whatsAppWhitelist.findMany({
        orderBy: { createdAt: 'desc' },
      });

      const pendingRequests = await getPendingRequests(updatedWhitelist);

      return NextResponse.json({
        success: true,
        message: `Phone ${cleanPhone} successfully added to Whitelist.`,
        entry,
        whitelist: updatedWhitelist,
        pendingRequests,
      });
    }

    if (action === 'REMOVE_WHITELIST') {
      if (id) {
        await db.whatsAppWhitelist.deleteMany({ where: { id } });
      } else if (phoneNumber) {
        await db.whatsAppWhitelist.deleteMany({ where: { phoneNumber: phoneNumber.trim() } });
      }

      const updatedWhitelist = await db.whatsAppWhitelist.findMany({
        orderBy: { createdAt: 'desc' },
      });

      const pendingRequests = await getPendingRequests(updatedWhitelist);

      return NextResponse.json({
        success: true,
        message: `Administrator removed from Whitelist.`,
        whitelist: updatedWhitelist,
        pendingRequests,
      });
    }

    // 3. Real Baileys Session Connection & Fresh QR Reset
    if (action === 'CONNECT' || action === 'REGENERATE_QR' || action === 'DISCONNECT') {
      const authFolder = path.resolve(process.cwd(), 'baileys_auth_info');
      if (fs.existsSync(authFolder)) {
        try {
          fs.rmSync(authFolder, { recursive: true, force: true });
        } catch (e) {
          console.error('Error clearing auth folder:', e);
        }
      }

      globalSession.status = 'CONNECTING';
      globalSession.qrCode = null;
      globalSession.phoneNumber = null;

      await db.whatsAppSession.upsert({
        where: { id: 'default' },
        update: { status: 'CONNECTING', qrCode: null, phoneNumber: null },
        create: { id: 'default', status: 'CONNECTING', qrCode: null, phoneNumber: null },
      });

      return NextResponse.json({
        success: true,
        message: 'WhatsApp Baileys Socket reset to generate new QR Code.',
        session: globalSession,
      });
    }

    // 4. Admin Command Execution in Pure English
    if (action === 'SEND_MESSAGE') {
      if (!message || !phoneNumber) {
        return NextResponse.json({ success: false, error: 'Phone and message are required' }, { status: 400 });
      }

      const inputDigits = phoneNumber.replace(/\D/g, '');
      const allWhitelist = await db.whatsAppWhitelist.findMany({ where: { isActive: true } });

      const isAuthorized = allWhitelist.find((w) => {
        const wDigits = w.phoneNumber.replace(/\D/g, '');
        return wDigits && (inputDigits.endsWith(wDigits) || wDigits.endsWith(inputDigits) || inputDigits === wDigits);
      });

      const outbound = await db.whatsAppMessage.create({
        data: {
          fromNumber: phoneNumber,
          senderName: 'Sandbox User',
          toNumber: 'Outcrop Silver CRM Bot',
          message,
          mediaUrl: mediaUrl || null,
          direction: 'INBOUND',
        },
      });

      let botResponse: string | null = null;
      const lowerMsg = message.toLowerCase();

      if (!isAuthorized) {
        const randomFact = SILVER_FUN_FACTS[Math.floor(Math.random() * SILVER_FUN_FACTS.length)];
        botResponse =
          `🔒 *Outcrop Silver CRM Security*\n\n` +
          `Hello. You are not authorized to operate this executive bot, but...\n\n` +
          `💡 *${randomFact}*\n\n` +
          `To learn more about the Santa Ana high-grade silver project by Outcrop Silver Corp. (TSX: OCG), please visit the official company website.`;
      } else {
        const adminFirstName = isAuthorized.name ? isAuthorized.name.split(' ')[0] : 'Administrator';

        if (lowerMsg.startsWith('/scan') || lowerMsg.startsWith('/card') || lowerMsg.startsWith('/escanear')) {
          botResponse =
            `📸 *Smart Business Card Scanner (2 Sides + Voice Note)*\n\n` +
            `*Step 1 of 3*: Send the **FRONT PHOTO** of the business card via WhatsApp chat.\n\n` +
            `💡 *Tip*: Ensure good lighting and clear focus.`;
        } else if (lowerMsg.startsWith('/tipify') || lowerMsg.startsWith('/stage') || lowerMsg.startsWith('/tipificar') || lowerMsg.startsWith('/etapa')) {
          const targetName = message.replace(/^\/(tipify|stage|tipificar|etapa)/i, '').trim();
          if (targetName) {
            const found = await db.contact.findFirst({
              where: { OR: [{ name: { contains: targetName } }, { company: { contains: targetName } }] },
            });
            if (found) {
              botResponse =
                `🎯 *Contact Pipeline Tipification: ${found.name}*\n` +
                `Current Stage: *${found.stage}*\n\n` +
                `Reply with the number for the new stage:\n\n` +
                STAGE_OPTIONS.map((s, idx) => `  *${idx + 1}*. ${s}`).join('\n');
            } else {
              botResponse = `⚠️ No contact matching "${targetName}" was found in the CRM.`;
            }
          } else {
            const recent = await db.contact.findMany({
              take: 5,
              orderBy: { createdAt: 'desc' },
            });
            botResponse =
              `🎯 *Pipeline Stage Tipification*\n\n` +
              `Reply with the number of the contact you wish to update:\n\n` +
              recent.map((c, idx) => `  *${idx + 1}*. *${c.name}* (${c.company || 'Investor'}) - Stage: _${c.stage}_`).join('\n') +
              `\n\n*(Or type \`/tipify [Name]\` directly)*`;
          }
        } else if (lowerMsg.startsWith('/search') || lowerMsg.startsWith('/buscar')) {
          const query = message.replace(/^\/(search|buscar)/i, '').trim();
          const found = await db.contact.findMany({
            where: {
              OR: [{ name: { contains: query } }, { company: { contains: query } }],
            },
            take: 5,
          });

          if (found.length > 0) {
            botResponse =
              `🔎 *CRM Search Results for ${adminFirstName} (${query})*:\n\n` +
              found
                .map(
                  (c) =>
                    `• *${c.name}*\n  Company: ${c.company || 'N/A'}\n  Stage: ${c.stage}\n  Email: ${c.email || 'N/A'}\n  Phone: ${c.phone || 'N/A'}\n  💡 Change stage: \`/tipify ${c.name}\``
                )
                .join('\n\n');
          } else {
            botResponse = `⚠️ No contacts matching "${query}" were found.`;
          }
        } else if (lowerMsg.startsWith('/create') || lowerMsg.startsWith('/crear')) {
          const rawArgs = message.replace(/^\/(create|crear)/i, '').trim();
          const parts = rawArgs.split(',').map((s: string) => s.trim()).filter((s: string) => s.length > 0);
          if (parts.length >= 1) {
            const newContact = await db.contact.create({
              data: {
                name: parts[0],
                company: parts[1] || 'Independent',
                email: parts[2] && parts[2].includes('@') ? parts[2] : `${parts[0].toLowerCase().replace(/\s+/g, '')}@investor.com`,
                investorType: parts[3] || 'Retail investor',
                stage: parts[4] || 'Lead Prospect',
                whatsapp: phoneNumber,
                source: 'WhatsApp One-Line Command',
                tags: '',
                customTags: '',
              },
            });
            botResponse =
              `🎉 *Contact Created Successfully (1-Line Command)*\n\n` +
              `• 👤 *Name*: ${newContact.name}\n` +
              `• 🏢 *Company*: ${newContact.company}\n` +
              `• 📧 *Email*: ${newContact.email}\n` +
              `• 💼 *Investor Type*: ${newContact.investorType}\n` +
              `• 📊 *Pipeline Stage*: ${newContact.stage}\n\n` +
              `💡 *Next Step*: To change stage, type:\n` +
              `\`/tipify ${newContact.name}\` or \`/stage ${newContact.name}\``;
          } else {
            botResponse =
              `➕ *Conversational Contact Creation Wizard*\n\n` +
              `*Step 1 of 5*: Enter the **Full Name** of the contact via WhatsApp.`;
          }
        } else if (lowerMsg.startsWith('/stats') || lowerMsg.startsWith('/summary') || lowerMsg.startsWith('/resumen')) {
          const totalContacts = await db.contact.count();
          const totalDeals = await db.deal.count();

          botResponse =
            `📊 *Outcrop Silver CRM Executive Dashboard*:\n` +
            `• Investors in Database: ${totalContacts}\n` +
            `• Active Pipeline Deals: ${totalDeals}\n` +
            `• Requested by: ${isAuthorized.name || adminFirstName}`;
        } else {
          botResponse =
            `👋 *Hello, ${adminFirstName}! Welcome to the Outcrop Silver CRM Executive Bot.*\n\n` +
            `Here is the menu of interactive commands available:\n\n` +
            `• 📸 \`/scan\` - Scan business card (Front + Back Photo + Voice Note)\n` +
            `• ➕ \`/create\` - Interactive contact wizard (or \`/create Name, Company, Email, Type\` in 1 line)\n` +
            `• 🎯 \`/tipify [Name]\` - Update contact stage via numbered list\n` +
            `• 🔍 \`/search [Name/Company]\` - Search contact profile in CRM\n` +
            `• 📊 \`/stats\` - View real-time executive dashboard metrics\n` +
            `• ❌ \`/cancel\` - Exit any wizard in progress`;
        }
      }

      if (botResponse) {
        await db.whatsAppMessage.create({
          data: {
            fromNumber: phoneNumber,
            senderName: 'CRM Bot',
            toNumber: phoneNumber,
            message: botResponse,
            direction: 'OUTBOUND',
          },
        });
      }

      return NextResponse.json({ success: true, messageSent: outbound, botResponse, isAuthorized: !!isAuthorized });
    }

    return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
