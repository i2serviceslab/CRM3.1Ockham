import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const rules = await prisma.workflowRule.findMany({
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ success: true, rules });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, triggerType, triggerValue, actionType, actionValue } = body;

    const rule = await prisma.workflowRule.create({
      data: {
        name,
        triggerType,
        triggerValue,
        actionType,
        actionValue,
        isActive: true,
      },
    });

    return NextResponse.json({ success: true, rule });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, isActive } = body;

    const rule = await prisma.workflowRule.update({
      where: { id },
      data: { isActive },
    });

    return NextResponse.json({ success: true, rule });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
