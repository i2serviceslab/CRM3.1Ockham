import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { frontImageUrl, backImageUrl, contactId } = body;

    if (!frontImageUrl) {
      return NextResponse.json({ success: false, error: 'Front card image is required' }, { status: 400 });
    }

    // Standard pattern extractors for card text
    // In browser client or server, OCR text is processed; here we provide standard extraction parsing & storage
    const extractedFrontText = body.extractedFrontText || 'Business Card Front Text';
    const extractedBackText = body.extractedBackText || 'Business Card Back Text';

    // Heuristic entity extraction regex
    const emailMatch = (extractedFrontText + ' ' + extractedBackText).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    const phoneMatch = (extractedFrontText + ' ' + extractedBackText).match(/(\+?\d{1,4}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
    
    const parsedData = {
      email: emailMatch ? emailMatch[0] : null,
      phone: phoneMatch ? phoneMatch[0] : null,
      rawFront: extractedFrontText,
      rawBack: extractedBackText,
    };

    const card = await prisma.businessCard.create({
      data: {
        contactId: contactId || null,
        frontImageUrl,
        backImageUrl: backImageUrl || null,
        extractedTextFront: extractedFrontText,
        extractedTextBack: extractedBackText,
        parsedDataJson: JSON.stringify(parsedData),
      },
    });

    if (contactId) {
      await prisma.timelineActivity.create({
        data: {
          contactId,
          type: 'CARD_SCAN',
          title: 'Tarjeta de Presentación Escaneada (2 Caras)',
          description: `Datos escaneados: ${parsedData.email || 'Email detectado'}, ${parsedData.phone || 'Teléfono'}.`,
        },
      });
    }

    return NextResponse.json({ success: true, card, parsedData });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
