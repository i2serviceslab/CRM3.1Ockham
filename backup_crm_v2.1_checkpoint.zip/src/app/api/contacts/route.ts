import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const investorType = searchParams.get('investorType');
    const interestLevel = searchParams.get('interestLevel');
    const stage = searchParams.get('stage');
    const source = searchParams.get('source');

    const where: any = {};

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { company: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
      ];
    }

    if (investorType && investorType !== 'ALL') {
      where.investorType = { contains: investorType };
    }

    if (interestLevel && interestLevel !== 'ALL') {
      where.interestLevel = { contains: interestLevel };
    }

    if (stage && stage !== 'ALL') {
      where.stage = stage;
    }

    if (source && source !== 'ALL') {
      where.source = source;
    }

    const contacts = await prisma.contact.findMany({
      where,
      include: {
        timelineActivities: { orderBy: { createdAt: 'desc' }, take: 10 },
        deals: true,
        documents: true,
        interactions: true,
        quotes: true,
        sourceRelationships: { include: { targetContact: true } },
        targetRelationships: { include: { sourceContact: true } },
      },
      orderBy: { updatedAt: 'desc' },
    });

    return NextResponse.json({ success: true, contacts });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, title, company, email, phone, whatsapp, location, bio, investorType, stage, source, leadScore } = body;

    if (!name) {
      return NextResponse.json({ success: false, error: 'Name is required' }, { status: 400 });
    }

    const contact = await prisma.contact.create({
      data: {
        name,
        title: title || null,
        company: company || null,
        email: email || null,
        phone: phone || null,
        whatsapp: whatsapp || null,
        location: location || null,
        bio: bio || null,
        investorType: investorType || 'Retail investor',
        stage: stage || 'Interested - early',
        source: source || 'Networking',
        leadScore: leadScore ? parseInt(leadScore, 10) : 10,
        timelineActivities: {
          create: {
            type: 'NOTE',
            title: 'Contacto Creado',
            description: `Contacto registrado en el CRM Outcrop Silver (${investorType} / ${stage}).`,
          },
        },
      },
    });

    return NextResponse.json({ success: true, contact });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
