import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, email, code } = body;

    if (action === 'REQUEST_CODE') {
      if (!email) {
        return NextResponse.json({ success: false, error: 'Email is required' }, { status: 400 });
      }

      // Generate 6-digit OTP pin
      const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 mins

      let user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        user = await prisma.user.create({
          data: {
            email,
            name: email.split('@')[0].toUpperCase(),
            role: 'Commercial',
            otpCode,
            otpExpiresAt: expiresAt,
          },
        });
      } else {
        user = await prisma.user.update({
          where: { email },
          data: { otpCode, otpExpiresAt: expiresAt },
        });
      }

      return NextResponse.json({
        success: true,
        message: 'Código de verificación generado y enviado al correo.',
        // Preview code for fast testing UI
        previewCode: otpCode,
        email,
      });
    }

    if (action === 'VERIFY_CODE') {
      if (!email || !code) {
        return NextResponse.json({ success: false, error: 'Email and code are required' }, { status: 400 });
      }

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
      }

      if (user.otpCode !== code) {
        return NextResponse.json({ success: false, error: 'Código de verificación incorrecto' }, { status: 400 });
      }

      // Clear OTP
      await prisma.user.update({
        where: { email },
        data: { otpCode: null, otpExpiresAt: null },
      });

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        },
      });
    }

    return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
