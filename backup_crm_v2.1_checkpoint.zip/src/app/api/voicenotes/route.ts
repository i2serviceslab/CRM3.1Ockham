import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { contactId, audioDataUrl, durationSeconds, transcript } = body;

    if (!contactId || !audioDataUrl) {
      return NextResponse.json({ success: false, error: 'Contact ID and audio data are required' }, { status: 400 });
    }

    const voiceNote = await prisma.voiceNote.create({
      data: {
        contactId,
        audioDataUrl,
        durationSeconds: durationSeconds || 0,
        transcript: transcript || 'Audio grabado en el CRM.',
      },
    });

    // Synthesize updated AI Executive Briefing fields
    const transcriptExcerpt = transcript ? transcript.slice(0, 120) : 'Actualización de voz registrada.';
    const newIcebreaker = `En nota de voz reciente: "${transcriptExcerpt}..."`;
    const newStrategicContext = `Inteligencia de voz procesada: ${transcript || 'Audio grabado'}. Relevante para seguimiento de inversión en metales.`;

    await prisma.contact.update({
      where: { id: contactId },
      data: {
        dynamicIcebreaker: newIcebreaker,
        strategicContext: newStrategicContext,
        leadScore: { increment: 5 },
      },
    });

    // Add activity to timeline
    await prisma.timelineActivity.create({
      data: {
        contactId,
        type: 'VOICE_NOTE',
        title: 'Nota de Voz Agregada',
        description: transcript || `Duración: ${durationSeconds || 0} segundos`,
      },
    });

    return NextResponse.json({ success: true, voiceNote });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
