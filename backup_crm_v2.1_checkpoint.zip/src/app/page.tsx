'use client';

import React, { useState, useEffect } from 'react';
import { Contact } from '@/types/crm';
import { OUTCROP_TAGS } from '@/lib/constants';
import { Navbar } from '@/components/layout/Navbar';
import { Sidebar, ActiveTab } from '@/components/layout/Sidebar';
import { MagicLogin } from '@/components/auth/MagicLogin';
import { Contact360View } from '@/components/contacts/Contact360View';
import { ContactModal } from '@/components/contacts/ContactModal';
import { VoiceNoteRecorder } from '@/components/contacts/VoiceNoteRecorder';
import { ContactGraphView } from '@/components/graph/ContactGraphView';
import { KanbanPipeline } from '@/components/pipeline/KanbanPipeline';
import { WorkflowsManager } from '@/components/workflows/WorkflowsManager';
import { WhatsAppManager } from '@/components/whatsapp/WhatsAppManager';
import { ThemeCustomizer } from '@/components/settings/ThemeCustomizer';
import { ConcaveCard } from '@/components/ui/ConcaveCard';
import { DailyScheduleWidget } from '@/components/ui/DailyScheduleWidget';
import { IRMetricsDashboard } from '@/components/analytics/IRMetricsDashboard';
import { SocialCalendarManager } from '@/components/social/SocialCalendarManager';

import {
  Plus,
  ArrowUpRight,
  Sparkles,
  BarChart3,
  Clock,
  Calendar,
  Video,
  Flame,
  Mail,
  CheckCircle2,
  Search,
  ChevronDown,
} from 'lucide-react';

export default function Home() {
  const [user, setUser] = useState<any>({
    id: 'usr-1',
    name: 'Nelson Carvajal',
    email: 'admin@outcropsilver.com',
    role: 'Admin IR Lead',
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('contacts');
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('ALL');
  const [selectedStage, setSelectedStage] = useState('ALL');
  const [selectedSource, setSelectedSource] = useState('ALL');

  // Modals
  const [selectedContact360, setSelectedContact360] = useState<Contact | null>(null);
  const [showAddContactModal, setShowAddContactModal] = useState(false);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showAgendaModal, setShowAgendaModal] = useState(false);

  // Branding Customization state with Official Outcrop Web Palette default (#00dfdf True Cyan & #a9aeb2 Metallic Silver)
  const [brandName, setBrandName] = useState('Outcrop Silver CRM');
  const [brandLogo, setBrandLogo] = useState('/logo.png');
  const [primaryColor, setPrimaryColor] = useState('#00dfdf');
  const [accentPurple, setAccentPurple] = useState('#a9aeb2');

  useEffect(() => {
    fetchContacts();
  }, [searchTerm, selectedType, selectedStage, selectedSource]);

  const fetchContacts = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams();
      if (searchTerm) query.append('search', searchTerm);
      
      if (selectedType && selectedType !== 'ALL') {
        if (selectedType === 'Hot Client' || selectedType === 'Great Interest') {
          query.append('interestLevel', 'High');
        } else if (selectedType === 'Medium Interest') {
          query.append('interestLevel', 'Medium');
        } else if (selectedType === 'Low Interest') {
          query.append('interestLevel', 'Low');
        } else {
          query.append('investorType', selectedType);
        }
      }
      
      if (selectedStage !== 'ALL') query.append('stage', selectedStage);
      if (selectedSource !== 'ALL') query.append('source', selectedSource);

      const res = await fetch(`/api/contacts?${query.toString()}`);
      const data = await res.json();
      if (data.success) {
        setContacts(data.contacts);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return <MagicLogin onLoginSuccess={(usr) => setUser(usr)} brandName={brandName} />;
  }

  return (
    <div
      style={{ backgroundColor: 'var(--bg-main)' }}
      className="min-h-screen text-slate-100 flex flex-col font-['Urbanist'] tracking-tight selection:bg-[#38bdf8] selection:text-zinc-950 transition-colors duration-200"
    >
      {/* Top Header Navbar */}
      <Navbar
        user={user}
        onLogout={() => setUser(null)}
        brandName={brandName}
        brandLogo={brandLogo}
        onOpenThemeSettings={() => setActiveTab('settings')}
        onOpenVideoCall={() => setShowVideoModal(true)}
        onOpenAgenda={() => setShowAgendaModal(true)}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        totalContacts={contacts.length}
      />

      {/* Main Layout (Fixed Sidebar + Main Body) */}
      <div className="flex flex-1 relative w-full">
        {/* Fixed Left Sidebar Menu */}
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} contactCount={contacts.length} />

        {/* Main Content Area */}
        <main className="flex-1 md:ml-64 w-full md:w-[calc(100%-16rem)] p-6 lg:p-8 space-y-10 overflow-x-hidden">
          {activeTab === 'contacts' && (
            <div className="space-y-10">
              
              {/* SECTION 1: WORKSPACE HEADER & DAILY SCHEDULE HERO WIDGET */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
                {/* Left Workspace Title & Stats Summary (Connected to var(--bg-card)) */}
                <ConcaveCard
                  bgColor="var(--bg-card)"
                  notchWidth={160}
                  notchHeight={50}
                  className="lg:col-span-2 shadow-2xl flex flex-col justify-between"
                  actionButton={
                    <button
                      onClick={() => setShowAddContactModal(true)}
                      className="hs-pill-btn hs-btn-lime shadow-xl py-2 px-5 text-xs font-black flex items-center gap-1.5 hover:scale-105 transition-transform"
                    >
                      <Plus className="w-4 h-4" />
                      <span>New Contact</span>
                    </button>
                  }
                >
                  <div>
                    <div className="flex items-center justify-between flex-wrap gap-4 pr-44">
                      <div>
                        <div className="flex items-center gap-4">
                          <h1 className="text-3xl font-black text-white tracking-tight uppercase">WORKSPACE</h1>
                          <span
                            style={{ backgroundColor: 'var(--primary-color)', color: '#000000' }}
                            className="px-3.5 py-1 rounded-full font-black text-xs shadow-md"
                          >
                            {contacts.length} Leads
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1.5 font-medium">
                          Investor relations management, mining funds, family offices, and brokers for Outcrop Silver.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Stats Counters Grid (Connected to var(--bg-card-inner)) */}
                  <div className="grid grid-cols-3 gap-4 pt-6 mt-6 border-t border-white/5">
                    <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">Active Investors</span>
                      <span className="text-2xl font-black text-white font-mono">{contacts.filter(c => c.stage.includes('Interested')).length}</span>
                    </div>

                    <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">Graph Connections</span>
                      <span style={{ color: 'var(--primary-color)' }} className="text-2xl font-black font-mono">14 Connections</span>
                    </div>

                    <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">Average Score</span>
                      <span style={{ color: 'var(--secondary-color)' }} className="text-2xl font-black font-mono">74 pts</span>
                    </div>
                  </div>
                </ConcaveCard>

                {/* Right: Daily Schedule Hero Widget */}
                <DailyScheduleWidget onOpenAgenda={() => setShowAgendaModal(true)} />
              </div>

              {/* SECTION 2: NEW LEADS */}
              <div className="space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-4 border-b border-white/5 pb-4">
                  <div className="flex items-center gap-3">
                    <h2 className="text-lg font-black text-white">New Leads</h2>
                    <span
                      style={{ backgroundColor: 'var(--bg-card)' }}
                      className="px-2.5 py-0.5 rounded-full text-slate-400 font-mono text-xs font-bold"
                    >
                      {contacts.length} Leads
                    </span>
                  </div>

                  {/* Filter Pills Scale */}
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {['ALL', 'Hot Client', 'Great Interest', 'Medium Interest', 'Low Interest'].map((filterItem) => {
                      const isSelected = selectedType === filterItem || (filterItem === 'ALL' && selectedType === 'ALL');

                      return (
                        <button
                          key={filterItem}
                          onClick={() => setSelectedType(filterItem)}
                          style={
                            isSelected
                              ? { backgroundColor: 'var(--primary-color)', color: '#000000' }
                              : { backgroundColor: 'var(--bg-card)' }
                          }
                          className={`px-4 py-1.5 rounded-full text-xs font-black transition-all ${
                            isSelected
                              ? 'shadow-md'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {filterItem}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Contact Cards Grid (Fully bound to var(--bg-card) & var(--bg-card-inner)) */}
                {loading ? (
                  <div className="text-center py-20 text-slate-500 font-mono text-xs">
                    Loading workspace contacts...
                  </div>
                ) : contacts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 w-full">
                    {contacts.map((contact) => {
                      return (
                        <ConcaveCard
                          key={contact.id}
                          bgColor="var(--bg-card)"
                          notchWidth={50}
                          notchHeight={50}
                          className="flex flex-col justify-between group transition-all shadow-2xl"
                          actionButton={
                            <button
                              onClick={() => setSelectedContact360(contact)}
                              style={{ backgroundColor: 'var(--bg-card-inner)' }}
                              className="w-9 h-9 rounded-full text-slate-200 flex items-center justify-center transition-transform hover:scale-110 shadow-md"
                              title="View 360° Profile"
                            >
                              <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                            </button>
                          }
                        >
                          <div>
                            {/* Card Top Header */}
                            <div className="flex items-start justify-between gap-3 mb-4 pr-12">
                              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                                <div
                                  style={{ borderColor: 'var(--primary-color)', backgroundColor: 'var(--bg-card-inner)' }}
                                  className="w-12 h-12 rounded-full border-2 text-white flex items-center justify-center font-black text-lg shadow-md shrink-0"
                                >
                                  {contact.name.charAt(0)}
                                </div>
                                <div className="min-w-0 flex-1">
                                  <h3 className="font-extrabold text-sm text-white group-hover:text-[#38bdf8] transition-colors truncate">
                                    {contact.name}
                                  </h3>
                                  <p className="text-xs text-slate-400 font-medium truncate">
                                    {contact.title || 'Investor'} {contact.company ? `at ${contact.company}` : ''}
                                  </p>
                                </div>
                              </div>
                            </div>

                            {/* Solid Dark Inset Box for Source & Rating (var(--bg-card-inner)) */}
                            <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-3.5 rounded-2xl mb-4 space-y-2">
                              <div className="flex items-center justify-between text-xs gap-2">
                                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider shrink-0">Source</span>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span style={{ backgroundColor: 'var(--bg-card)' }} className="px-2.5 py-0.5 rounded-full text-slate-200 text-[10px] font-bold">
                                    {contact.source || 'LinkedIn'}
                                  </span>
                                  <span style={{ backgroundColor: 'var(--bg-card)' }} className="px-2.5 py-0.5 rounded-full text-slate-400 text-[10px] font-bold">
                                    Email
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center justify-between pt-1 border-t border-white/5">
                                <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-300">
                                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                                  <span className="text-[10px] uppercase tracking-wider text-slate-400">Rating</span>
                                </div>

                                {/* 5 Dots Rating Scale */}
                                <div className="flex items-center gap-1 shrink-0">
                                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                                  <span className="w-2 h-2 rounded-full bg-orange-500" />
                                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'var(--primary-color)' }} />
                                </div>
                              </div>
                            </div>

                            {/* Outcrop Tag Taxonomy Badges */}
                            <div className="flex items-center gap-2 flex-wrap mb-4">
                              <span
                                style={{
                                  backgroundColor: 'var(--primary-color-alpha)',
                                  color: 'var(--primary-color)',
                                }}
                                className="inline-flex whitespace-nowrap text-[10px] font-black px-3 py-1 rounded-full"
                              >
                                {contact.stage}
                              </span>
                              <span style={{ backgroundColor: 'var(--bg-card-inner)' }} className="inline-flex whitespace-nowrap text-[10px] font-black px-3 py-1 rounded-full text-slate-300">
                                {contact.investorType}
                              </span>
                            </div>
                          </div>

                          {/* Card Bottom Bar */}
                          <div className="pt-4 border-t border-white/5 flex items-center justify-between gap-2">
                            <span style={{ color: 'var(--primary-color)' }} className="text-[11px] font-mono font-bold shrink-0">
                              Score: {contact.leadScore} pts
                            </span>

                            <button
                              onClick={() => setSelectedContact360(contact)}
                              className="hs-pill-btn hs-btn-lime py-1.5 px-4 text-xs font-black shrink-0"
                            >
                              <span>360° Profile</span>
                            </button>
                          </div>
                        </ConcaveCard>
                      );
                    })}
                  </div>
                ) : (
                  <div style={{ backgroundColor: 'var(--bg-card)' }} className="text-center py-20 p-8 rounded-[28px] text-slate-400 text-xs">
                    No leads found matching filters.
                  </div>
                )}
              </div>

              {/* SECTION 3: YOUR DAYS TASKS */}
              <div className="space-y-6 pt-4 border-t border-white/5">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <h2 className="text-xl font-black text-white">Your Days Tasks</h2>
                    <span style={{ backgroundColor: 'var(--bg-card)' }} className="px-2.5 py-0.5 rounded-full text-slate-400 font-mono text-xs font-bold">
                      16 Tasks
                    </span>
                  </div>

                  {/* Task Status Filters */}
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {['All', 'Hot', 'Due Today', 'Overdue', 'Completed'].map((taskFilter, i) => (
                      <button
                        key={taskFilter}
                        style={{
                          backgroundColor: i === 0 ? 'var(--bg-card-inner)' : 'var(--bg-card)',
                        }}
                        className={`px-4 py-1.5 rounded-full text-xs font-black transition-all ${
                          i === 0 ? 'text-white' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {taskFilter}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Task Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Task Card 1: Solid Bold Primary Accent (Google Meet Call) */}
                  <ConcaveCard
                    bgColor="var(--primary-color)"
                    notchWidth={50}
                    notchHeight={50}
                    actionButton={
                      <button className="w-8 h-8 rounded-full bg-black/20 text-black flex items-center justify-center">
                        <ArrowUpRight className="w-4 h-4 stroke-[3]" />
                      </button>
                    }
                    className="shadow-2xl flex flex-col justify-between space-y-4 text-black"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3 pr-12">
                        <div className="flex items-center gap-2.5">
                          <img
                            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80"
                            alt="Peter Thomas"
                            className="w-9 h-9 rounded-full object-cover border-2 border-black"
                          />
                          <div>
                            <h4 className="text-xs font-black text-black">Peter Thomas</h4>
                            <p className="text-[10px] font-bold text-zinc-900">CEO at Madira Ink</p>
                          </div>
                        </div>
                      </div>

                      <div className="my-3 space-y-1">
                        <h3 className="text-xl font-black text-black tracking-tight">Google Meet Call</h3>
                        <p className="text-xs font-bold text-zinc-900 font-mono">28.03.2023 at 2 pm</p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-black/20 flex items-center justify-between">
                      <div className="px-3 py-1.5 rounded-full bg-black/20 text-black text-xs font-black flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-black animate-ping" />
                        <span>Call scheduled</span>
                        <ChevronDown className="w-3.5 h-3.5" />
                      </div>

                      <div className="flex items-center gap-2">
                        <button className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center">
                          <Mail className="w-4 h-4" />
                        </button>
                        <button onClick={() => setShowVideoModal(true)} className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center">
                          <Video className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </ConcaveCard>

                  {/* Task Card 2: Send Proposal Card */}
                  <ConcaveCard
                    bgColor="var(--bg-card)"
                    notchWidth={50}
                    notchHeight={50}
                    actionButton={
                      <button style={{ backgroundColor: 'var(--bg-card-inner)' }} className="w-8 h-8 rounded-full text-slate-200 flex items-center justify-center">
                        <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    }
                    className="flex flex-col justify-between space-y-4 shadow-xl"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3 pr-12">
                        <div className="flex items-center gap-2.5">
                          <img
                            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                            alt="Alesha Hyacinth"
                            className="w-9 h-9 rounded-full object-cover border-2 border-white/20"
                          />
                          <div>
                            <h4 className="text-xs font-black text-white">Alesha Hyacinth</h4>
                            <p className="text-[10px] font-bold text-slate-400">CEO at Metamorphosis</p>
                          </div>
                        </div>
                      </div>

                      <div className="my-3 space-y-1">
                        <h3 className="text-xl font-black text-white tracking-tight">Send Proposal</h3>
                        <p style={{ color: 'var(--primary-color)' }} className="text-xs font-mono font-bold">
                          Amount: $ 20,000
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                      <span style={{ backgroundColor: 'var(--bg-card-inner)' }} className="px-3 py-1.5 rounded-full text-slate-300 text-xs font-bold">
                        Waiting Proposal ▾
                      </span>
                      <button style={{ backgroundColor: 'var(--bg-card-inner)' }} className="w-8 h-8 rounded-full text-white flex items-center justify-center">
                        <Mail className="w-4 h-4" />
                      </button>
                    </div>
                  </ConcaveCard>

                  {/* Task Card 3: Google Meet Call */}
                  <ConcaveCard
                    bgColor="var(--bg-card)"
                    notchWidth={50}
                    notchHeight={50}
                    actionButton={
                      <button onClick={() => setShowVideoModal(true)} style={{ backgroundColor: 'var(--bg-card-inner)' }} className="w-8 h-8 rounded-full text-slate-200 flex items-center justify-center">
                        <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    }
                    className="flex flex-col justify-between space-y-4 shadow-xl"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3 pr-12">
                        <div className="flex items-center gap-2.5">
                          <img
                            src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&q=80"
                            alt="Miriam Fannie"
                            className="w-9 h-9 rounded-full object-cover border-2 border-white/20"
                          />
                          <div>
                            <h4 className="text-xs font-black text-white">Miriam Fannie</h4>
                            <p className="text-[10px] font-bold text-slate-400">Brand Manager at Summit</p>
                          </div>
                        </div>
                      </div>

                      <div className="my-3 space-y-1">
                        <h3 className="text-xl font-black text-white tracking-tight">Google Meet Call</h3>
                        <p className="text-xs font-mono font-bold text-slate-400">28.03.2023 at 8 pm</p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                      <span style={{ backgroundColor: 'var(--bg-card-inner)' }} className="px-3 py-1.5 rounded-full text-slate-300 text-xs font-bold">
                        Call scheduled ▾
                      </span>
                      <button onClick={() => setShowVideoModal(true)} style={{ backgroundColor: 'var(--bg-card-inner)' }} className="w-8 h-8 rounded-full text-white flex items-center justify-center">
                        <Video className="w-4 h-4" />
                      </button>
                    </div>
                  </ConcaveCard>

                </div>
              </div>

            </div>
          )}

          {activeTab === 'graph' && (
            <ContactGraphView
              contacts={contacts}
              onOpen360={(c) => setSelectedContact360(c)}
              onRefresh={fetchContacts}
            />
          )}

          {activeTab === 'followup' && (
            <KanbanPipeline
              contacts={contacts}
              onOpen360={(c) => setSelectedContact360(c)}
              onRefresh={fetchContacts}
            />
          )}

          {activeTab === 'voice-notes' && (
            <VoiceNoteRecorder contacts={contacts} onSuccess={fetchContacts} />
          )}

          {activeTab === 'whatsapp' && <WhatsAppManager />}

          {activeTab === 'workflows' && <WorkflowsManager />}

          {activeTab === 'social-calendar' && <SocialCalendarManager />}

          {activeTab === 'settings' && (
            <ThemeCustomizer
              brandName={brandName}
              setBrandName={setBrandName}
              brandLogo={brandLogo}
              setBrandLogo={setBrandLogo}
              primaryColor={primaryColor}
              setPrimaryColor={setPrimaryColor}
              accentPurple={accentPurple}
              setAccentPurple={setAccentPurple}
            />
          )}

          {activeTab === 'analytics' && (
            <IRMetricsDashboard contacts={contacts} onOpenContact360={(c) => setSelectedContact360(c)} />
          )}
        </main>
      </div>

      {/* Interactive Floating 360° Dossier */}
      {selectedContact360 && (
        <Contact360View
          contact={selectedContact360}
          onClose={() => setSelectedContact360(null)}
          onRefresh={fetchContacts}
          onOpenCardScanner={() => {
            setSelectedContact360(null);
            setShowAddContactModal(true);
          }}
          onOpenVoiceRecorder={() => {
            setSelectedContact360(null);
            setActiveTab('voice-notes');
          }}
        />
      )}

      {showAddContactModal && (
        <ContactModal
          onClose={() => setShowAddContactModal(false)}
          onSuccess={fetchContacts}
        />
      )}

      {/* Video Call Modal */}
      {showVideoModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div style={{ backgroundColor: 'var(--bg-card)' }} className="w-full max-w-lg p-6 rounded-[28px] shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Video style={{ color: 'var(--primary-color)' }} className="w-4 h-4" />
                <span>IR Virtual Room & Meeting Call</span>
              </h3>
              <button onClick={() => setShowVideoModal(false)} style={{ backgroundColor: 'var(--bg-card-inner)' }} className="w-8 h-8 rounded-full text-slate-400 hover:text-white flex items-center justify-center">
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl space-y-2">
                <span className="text-xs font-black text-white block">Select Investor for Room:</span>
                <select className="w-full hs-input-hero text-xs">
                  {contacts.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.company || 'Investor'})
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl text-xs text-slate-300 space-y-2">
                <div className="flex items-center gap-2 font-bold" style={{ color: 'var(--primary-color)' }}>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Virtual Room Link Generated</span>
                </div>
                <p style={{ backgroundColor: 'var(--bg-card)' }} className="font-mono text-[11px] text-slate-400 p-2.5 rounded-xl truncate">
                  https://meet.outcropsilver.com/ir-session-live-room
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button onClick={() => setShowVideoModal(false)} className="hs-pill-btn hs-btn-dark py-2 px-4 text-xs font-bold">
                  Close
                </button>

                <button onClick={() => { alert('Launching live IR room...'); setShowVideoModal(false); }} className="hs-pill-btn hs-btn-lime py-2 px-5 text-xs font-black">
                  Launch Room
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Agenda & Schedule Modal */}
      {showAgendaModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div style={{ backgroundColor: 'var(--bg-card)' }} className="w-full max-w-xl p-6 rounded-[28px] shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Calendar style={{ color: 'var(--primary-color)' }} className="w-4 h-4" />
                <span>Executive Schedule & IR Agenda</span>
              </h3>
              <button onClick={() => setShowAgendaModal(false)} style={{ backgroundColor: 'var(--bg-card-inner)' }} className="w-8 h-8 rounded-full text-slate-400 hover:text-white flex items-center justify-center">
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black text-white">Santa Ana Project Update Call</h4>
                  <p className="text-[10px] text-slate-400">With Patricia Gómez (Pan American Silver)</p>
                </div>
                <span style={{ backgroundColor: 'var(--primary-color)', color: '#000000' }} className="px-3 py-1 rounded-full text-[10px] font-black">
                  Today • 2:00 PM
                </span>
              </div>

              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black text-white">Technical Assay Presentation</h4>
                  <p className="text-[10px] text-slate-400">With Dr. Guillermo Gutiérrez (Andean Capital)</p>
                </div>
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-black">
                  Tomorrow • 10:30 AM
                </span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button onClick={() => setShowAgendaModal(false)} className="hs-pill-btn hs-btn-lime py-2 px-5 text-xs font-black">
                Got it
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
