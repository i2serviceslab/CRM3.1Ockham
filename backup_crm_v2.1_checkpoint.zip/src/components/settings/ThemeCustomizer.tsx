'use client';

import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Sparkles,
  Check,
  RotateCcw,
  Image as ImageIcon,
  Palette,
  Key,
  Cpu,
  ShieldCheck,
  Zap,
  AlertCircle,
  Eye,
  EyeOff,
  Layers,
  SlidersHorizontal,
  Droplet,
  Globe,
  Sun,
  Moon,
  ExternalLink,
  Brush,
} from 'lucide-react';

interface ThemeCustomizerProps {
  brandName: string;
  setBrandName: (name: string) => void;
  brandLogo: string;
  setBrandLogo: (logo: string) => void;
  primaryColor: string;
  setPrimaryColor: (color: string) => void;
  accentPurple: string;
  setAccentPurple: (color: string) => void;
}

export const ThemeCustomizer: React.FC<ThemeCustomizerProps> = ({
  brandName,
  setBrandName,
  brandLogo,
  setBrandLogo,
  primaryColor,
  setPrimaryColor,
  accentPurple,
  setAccentPurple,
}) => {
  const [activeTab, setActiveTab] = useState<'preset' | 'palette' | 'branding' | 'ai-keys'>('preset');
  const [saved, setSaved] = useState(false);

  // Background & Container Color Customization State
  const [bgMain, setBgMain] = useState('#000000');
  const [bgCard, setBgCard] = useState('#151922');
  const [bgCardInner, setBgCardInner] = useState('#1f2430');
  const [textColor, setTextColor] = useState('#ffffff');
  const [cardOpacity, setCardOpacity] = useState(100);
  const [borderRadius, setBorderRadius] = useState(28);
  const [enableGradient, setEnableGradient] = useState(false);

  // AI Provider Keys State
  const [openaiKey, setOpenaiKey] = useState(
    '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'
  );
  const [geminiKey, setGeminiKey] = useState('');
  const [claudeKey, setClaudeKey] = useState('');
  const [showKeys, setShowKeys] = useState(false);

  const [testStatus, setTestStatus] = useState<{ loading: boolean; success?: boolean; msg?: string } | null>(null);

  useEffect(() => {
    // Load stored theme variables from localStorage
    const storedBgMain = localStorage.getItem('crm_bg_main') || '#000000';
    const storedBgCard = localStorage.getItem('crm_bg_card') || '#151922';
    const storedBgInner = localStorage.getItem('crm_bg_card_inner') || '#1f2430';
    const storedTextColor = localStorage.getItem('crm_text_color') || '#ffffff';
    const storedPrimary = localStorage.getItem('crm_primary_color') || '#00dfdf';
    const storedSecondary = localStorage.getItem('crm_accent_purple') || '#a9aeb2';
    const storedOpenAi = localStorage.getItem('crm_openai_key');

    if (storedBgMain) applyBgMain(storedBgMain);
    if (storedBgCard) applyBgCard(storedBgCard);
    if (storedBgInner) applyBgCardInner(storedBgInner);
    if (storedTextColor) applyTextColor(storedTextColor);
    if (storedPrimary) applyPrimaryColor(storedPrimary);
    if (storedSecondary) applySecondaryColor(storedSecondary);
    if (storedOpenAi) setOpenaiKey(storedOpenAi);
  }, []);

  const applyBgMain = (colorHex: string) => {
    setBgMain(colorHex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--bg-main', colorHex);
      localStorage.setItem('crm_bg_main', colorHex);
    }
  };

  const applyBgCard = (colorHex: string) => {
    setBgCard(colorHex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--bg-card', colorHex);
      localStorage.setItem('crm_bg_card', colorHex);
    }
  };

  const applyBgCardInner = (colorHex: string) => {
    setBgCardInner(colorHex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--bg-card-inner', colorHex);
      localStorage.setItem('crm_bg_card_inner', colorHex);
    }
  };

  const applyTextColor = (colorHex: string) => {
    setTextColor(colorHex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--text-primary', colorHex);
      localStorage.setItem('crm_text_color', colorHex);
    }
  };

  const applyPrimaryColor = (colorHex: string) => {
    setPrimaryColor(colorHex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--primary-color', colorHex);
      document.documentElement.style.setProperty('--primary-color-hover', colorHex);
      document.documentElement.style.setProperty('--primary-color-alpha', `${colorHex}33`);
      localStorage.setItem('crm_primary_color', colorHex);
    }
  };

  const applySecondaryColor = (colorHex: string) => {
    setAccentPurple(colorHex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--secondary-color', colorHex);
      document.documentElement.style.setProperty('--secondary-color-alpha', `${colorHex}33`);
      localStorage.setItem('crm_accent_purple', colorHex);
    }
  };

  // One-Click Official Outcrop & Preset Themes
  const applyPresetTheme = (presetKey: string) => {
    switch (presetKey) {
      case 'official-outcrop-web':
        // Extracted directly from https://herramientas-outcrop.wu48i0.easypanel.host/style.css
        applyPrimaryColor('#00dfdf'); // True Cyan detail accent
        applySecondaryColor('#a9aeb2'); // Metallic Silver Logo Accent
        applyBgMain('#0f172a'); // Dark Slate Steel
        applyBgCard('#1e2430'); // Dark Steel Card
        applyBgCardInner('#282f40'); // Inset Steel
        applyTextColor('#ffffff');
        break;

      case 'outcrop-light-web':
        // Light Metallic Silver Mode directly from official web
        applyPrimaryColor('#00dfdf');
        applySecondaryColor('#57696e');
        applyBgMain('#f8fafc'); // Soft off-white silver
        applyBgCard('#ffffff'); // Pure white card
        applyBgCardInner('#f1f5f9'); // Soft silver inset
        applyTextColor('#0f172a'); // High contrast dark text
        break;

      case 'outcrop-ice-black':
        // Deep Pitch Black & Ice Blue Core
        applyPrimaryColor('#38bdf8');
        applySecondaryColor('#c084fc');
        applyBgMain('#000000');
        applyBgCard('#151922');
        applyBgCardInner('#1f2430');
        applyTextColor('#ffffff');
        break;

      case 'emerald-mining':
        // Emerald Prospector & Amber Gold
        applyPrimaryColor('#10b981');
        applySecondaryColor('#f59e0b');
        applyBgMain('#090a0f');
        applyBgCard('#121820');
        applyBgCardInner('#1c2430');
        applyTextColor('#ffffff');
        break;

      case 'deep-space-purple':
        // Titanium Violet & Deep Space
        applyPrimaryColor('#a855f7');
        applySecondaryColor('#06b6d4');
        applyBgMain('#0a0518');
        applyBgCard('#160e2e');
        applyBgCardInner('#221742');
        applyTextColor('#ffffff');
        break;

      default:
        break;
    }
  };

  const handleSave = () => {
    applyBgMain(bgMain);
    applyBgCard(bgCard);
    applyBgCardInner(bgCardInner);
    applyTextColor(textColor);
    applyPrimaryColor(primaryColor);
    applySecondaryColor(accentPurple);

    localStorage.setItem('crm_brand_name', brandName);
    localStorage.setItem('crm_brand_logo', brandLogo);
    localStorage.setItem('crm_openai_key', openaiKey);
    localStorage.setItem('crm_gemini_key', geminiKey);
    localStorage.setItem('crm_claude_key', claudeKey);

    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleTestConnection = async () => {
    setTestStatus({ loading: true });
    try {
      const res = await fetch('/api/ai/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'ping' }),
      });
      const data = await res.json();
      if (data.success) {
        setTestStatus({
          loading: false,
          success: true,
          msg: `Conexión Exitosa con OpenAI (${data.modelUsed}). API Key Operativa!`,
        });
      } else {
        setTestStatus({
          loading: false,
          success: false,
          msg: data.error || 'Fallo en la prueba de conexión API Key.',
        });
      }
    } catch (err: any) {
      setTestStatus({
        loading: false,
        success: false,
        msg: 'Error de red al probar conexión de API Key.',
      });
    }
  };

  return (
    <div className="space-y-8 font-['Urbanist'] max-w-5xl mx-auto">
      {/* Settings Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 border-b border-white/10 pb-6">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight uppercase flex items-center gap-3">
            <Sliders className="w-8 h-8" style={{ color: 'var(--primary-color)' }} />
            <span>Motor de Branding, Temas SaaS & Colores Oficiales Outcrop</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 font-medium">
            Sincroniza los colores oficiales de la web de Outcrop Silver o personaliza libremente fondos, tarjetas, transparencias y degradés para SaaS.
          </p>
        </div>

        {saved && (
          <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/20 text-emerald-300 rounded-full text-xs font-black border border-emerald-500/30 animate-fadeIn">
            <Check className="w-4 h-4" />
            <span>¡Configuración Guardada!</span>
          </div>
        )}
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-3 border-b border-white/10 pb-3 overflow-x-auto">
        <button
          onClick={() => setActiveTab('preset')}
          className={`px-5 py-2.5 rounded-full text-xs font-black transition-all flex items-center gap-2 ${
            activeTab === 'preset'
              ? 'bg-[#00dfdf] text-black shadow-lg'
              : 'bg-[#181a24] text-slate-400 hover:text-white'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>Paletas Oficiales & Presets SaaS</span>
        </button>

        <button
          onClick={() => setActiveTab('palette')}
          className={`px-5 py-2.5 rounded-full text-xs font-black transition-all flex items-center gap-2 ${
            activeTab === 'palette'
              ? 'bg-[#00dfdf] text-black shadow-lg'
              : 'bg-[#181a24] text-slate-400 hover:text-white'
          }`}
        >
          <Droplet className="w-4 h-4" />
          <span>Editor Libre de Colores & Degradés</span>
        </button>

        <button
          onClick={() => setActiveTab('branding')}
          className={`px-5 py-2.5 rounded-full text-xs font-black transition-all flex items-center gap-2 ${
            activeTab === 'branding'
              ? 'bg-[#00dfdf] text-black shadow-lg'
              : 'bg-[#181a24] text-slate-400 hover:text-white'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>Branding & Logo Oficial</span>
        </button>

        <button
          onClick={() => setActiveTab('ai-keys')}
          className={`px-5 py-2.5 rounded-full text-xs font-black transition-all flex items-center gap-2 ${
            activeTab === 'ai-keys'
              ? 'bg-[#00dfdf] text-black shadow-lg'
              : 'bg-[#181a24] text-slate-400 hover:text-white'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Proveedores de IA & API Keys</span>
        </button>
      </div>

      {/* TAB 1: PRESET THEMES (OFFICIAL OUTCROP WEB COLORS EXTRATED LIVE) */}
      {activeTab === 'preset' && (
        <div className="space-y-8 animate-fadeIn">
          {/* Official Web Banner Callout */}
          <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-6 rounded-[28px] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#00dfdf] animate-pulse" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Paleta Oficial Extraída de la Web Outcrop Silver
                </h3>
              </div>
              <a
                href="https://herramientas-outcrop.wu48i0.easypanel.host/index.html"
                target="_blank"
                rel="noreferrer"
                className="text-xs font-bold text-sky-400 hover:underline flex items-center gap-1"
              >
                <span>Ver Sitio Web Referente</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
            <p className="text-xs text-slate-400 font-medium">
              Colores extraídos directamente de <code className="text-[#00dfdf]">style.css</code>: Acento Cyan Principal (<code className="text-[#00dfdf]">#00dfdf</code>), Plata Metálico (<code className="text-slate-300">#a9aeb2</code>) y Slate Acero (<code className="text-slate-400">#0f172a</code>).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Preset 1: Official Outcrop True Cyan & Slate Steel */}
            <div
              onClick={() => applyPresetTheme('official-outcrop-web')}
              style={{ backgroundColor: 'var(--bg-card)' }}
              className="p-6 rounded-[28px] border-2 border-[#00dfdf]/40 hover:border-[#00dfdf] cursor-pointer transition-all space-y-4 shadow-2xl group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 rounded-full bg-[#00dfdf]" />
                  <h4 className="text-sm font-black text-white uppercase group-hover:text-[#00dfdf] transition-colors">
                    Outcrop Silver Oficial (True Cyan)
                  </h4>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-[#00dfdf]/20 text-[#00dfdf] text-[10px] font-black">
                  WEB DESIGN
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Acento Cyan vibrante (#00dfdf), plata metálico (#a9aeb2) y contenedores slate acero de alta fidelidad.
              </p>
              <div className="flex items-center gap-2 pt-2">
                <span className="w-6 h-6 rounded-full bg-[#00dfdf] shadow-md" title="Primary: #00dfdf" />
                <span className="w-6 h-6 rounded-full bg-[#a9aeb2] shadow-md" title="Silver: #a9aeb2" />
                <span className="w-6 h-6 rounded-full bg-[#0f172a] border border-white/20" title="Void: #0f172a" />
                <span className="w-6 h-6 rounded-full bg-[#1e2430] border border-white/20" title="Card: #1e2430" />
              </div>
            </div>

            {/* Preset 2: Official Outcrop Light Metallic Silver Mode */}
            <div
              onClick={() => applyPresetTheme('outcrop-light-web')}
              style={{ backgroundColor: 'var(--bg-card)' }}
              className="p-6 rounded-[28px] border border-white/10 hover:border-[#00dfdf] cursor-pointer transition-all space-y-4 shadow-2xl group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sun className="w-4 h-4 text-amber-400" />
                  <h4 className="text-sm font-black text-white uppercase group-hover:text-[#00dfdf] transition-colors">
                    Outcrop Light Metallic Mode (Claro)
                  </h4>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-[10px] font-black">
                  MODO CLARO
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Fondo suave plata-blanco (#f8fafc), tarjetas en blanco puro (#ffffff) y acento True Cyan (#00dfdf).
              </p>
              <div className="flex items-center gap-2 pt-2">
                <span className="w-6 h-6 rounded-full bg-[#00dfdf] shadow-md" />
                <span className="w-6 h-6 rounded-full bg-[#57696e] shadow-md" />
                <span className="w-6 h-6 rounded-full bg-[#f8fafc] border border-slate-400" />
                <span className="w-6 h-6 rounded-full bg-[#ffffff] border border-slate-400" />
              </div>
            </div>

            {/* Preset 3: Deep Pitch Black & Ice Blue */}
            <div
              onClick={() => applyPresetTheme('outcrop-ice-black')}
              style={{ backgroundColor: 'var(--bg-card)' }}
              className="p-6 rounded-[28px] border border-white/10 hover:border-sky-400 cursor-pointer transition-all space-y-4 shadow-2xl group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4 text-sky-400" />
                  <h4 className="text-sm font-black text-white uppercase group-hover:text-sky-400 transition-colors">
                    Outcrop Ice Blue & Pitch Black (Oscuro)
                  </h4>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-sky-400/20 text-sky-400 text-[10px] font-black">
                  PITCH BLACK
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Fondo negro absoluto (#000000), tarjetas carbón oscuro (#151922) y acento azul hielo (#38bdf8).
              </p>
              <div className="flex items-center gap-2 pt-2">
                <span className="w-6 h-6 rounded-full bg-[#38bdf8] shadow-md" />
                <span className="w-6 h-6 rounded-full bg-[#c084fc] shadow-md" />
                <span className="w-6 h-6 rounded-full bg-[#000000] border border-white/20" />
                <span className="w-6 h-6 rounded-full bg-[#151922] border border-white/20" />
              </div>
            </div>

            {/* Preset 4: Emerald Mining Prospector */}
            <div
              onClick={() => applyPresetTheme('emerald-mining')}
              style={{ backgroundColor: 'var(--bg-card)' }}
              className="p-6 rounded-[28px] border border-white/10 hover:border-emerald-400 cursor-pointer transition-all space-y-4 shadow-2xl group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 rounded-full bg-emerald-400" />
                  <h4 className="text-sm font-black text-white uppercase group-hover:text-emerald-400 transition-colors">
                    Emerald Prospector (Minero Esmeralda)
                  </h4>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-black">
                  MINING GREEN
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Acento verde esmeralda (#10b981), detalles en oro (#f59e0b) y fondo verde obsidiana (#090a0f).
              </p>
              <div className="flex items-center gap-2 pt-2">
                <span className="w-6 h-6 rounded-full bg-[#10b981] shadow-md" />
                <span className="w-6 h-6 rounded-full bg-[#f59e0b] shadow-md" />
                <span className="w-6 h-6 rounded-full bg-[#090a0f] border border-white/20" />
                <span className="w-6 h-6 rounded-full bg-[#121820] border border-white/20" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: EDITOR LIBRE DE COLORES, FONDO & DEGRADÉS */}
      {activeTab === 'palette' && (
        <div className="space-y-8 animate-fadeIn">
          {/* Section 1: Background & Card Fill Controls */}
          <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-8 rounded-[28px] space-y-6">
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <Droplet style={{ color: 'var(--primary-color)' }} className="w-5 h-5" />
              <span>Fondo General & Contenedores de Tarjetas</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Main Background Color */}
              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-5 rounded-2xl space-y-3">
                <label className="text-xs font-black text-white block uppercase tracking-wider">
                  Fondo Principal de App:
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={bgMain}
                    onChange={(e) => applyBgMain(e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                  />
                  <input
                    type="text"
                    value={bgMain}
                    onChange={(e) => applyBgMain(e.target.value)}
                    className="hs-input-hero py-2 text-xs font-mono font-bold"
                  />
                </div>
                <div className="flex items-center gap-2 pt-2 flex-wrap">
                  <button
                    onClick={() => applyBgMain('#000000')}
                    className="px-2.5 py-1 rounded-full bg-black text-white text-[10px] font-black border border-white/20"
                  >
                    #000000 (Negro)
                  </button>
                  <button
                    onClick={() => applyBgMain('#0f172a')}
                    className="px-2.5 py-1 rounded-full bg-[#0f172a] text-white text-[10px] font-black border border-white/20"
                  >
                    #0f172a (Slate)
                  </button>
                  <button
                    onClick={() => applyBgMain('#f8fafc')}
                    className="px-2.5 py-1 rounded-full bg-[#f8fafc] text-black text-[10px] font-black border border-slate-300"
                  >
                    #f8fafc (Claro)
                  </button>
                </div>
              </div>

              {/* Card Container Color */}
              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-5 rounded-2xl space-y-3">
                <label className="text-xs font-black text-white block uppercase tracking-wider">
                  Color de Tarjetas (Bloque Sólido):
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={bgCard}
                    onChange={(e) => applyBgCard(e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                  />
                  <input
                    type="text"
                    value={bgCard}
                    onChange={(e) => applyBgCard(e.target.value)}
                    className="hs-input-hero py-2 text-xs font-mono font-bold"
                  />
                </div>
                <div className="flex items-center gap-2 pt-2 flex-wrap">
                  <button
                    onClick={() => applyBgCard('#151922')}
                    className="px-2.5 py-1 rounded-full bg-[#151922] text-white text-[10px] font-black"
                  >
                    #151922 (Obsidiana)
                  </button>
                  <button
                    onClick={() => applyBgCard('#1e2430')}
                    className="px-2.5 py-1 rounded-full bg-[#1e2430] text-white text-[10px] font-black"
                  >
                    #1e2430 (Steel)
                  </button>
                  <button
                    onClick={() => applyBgCard('#ffffff')}
                    className="px-2.5 py-1 rounded-full bg-[#ffffff] text-black text-[10px] font-black border border-slate-300"
                  >
                    #ffffff (Blanco)
                  </button>
                </div>
              </div>

              {/* Card Inset Color */}
              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-5 rounded-2xl space-y-3">
                <label className="text-xs font-black text-white block uppercase tracking-wider">
                  Color de Cajas Internas Inset:
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={bgCardInner}
                    onChange={(e) => applyBgCardInner(e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                  />
                  <input
                    type="text"
                    value={bgCardInner}
                    onChange={(e) => applyBgCardInner(e.target.value)}
                    className="hs-input-hero py-2 text-xs font-mono font-bold"
                  />
                </div>
                <div className="flex items-center gap-2 pt-2 flex-wrap">
                  <button
                    onClick={() => applyBgCardInner('#1f2430')}
                    className="px-2.5 py-1 rounded-full bg-[#1f2430] text-white text-[10px] font-black"
                  >
                    #1f2430 (Dark)
                  </button>
                  <button
                    onClick={() => applyBgCardInner('#282f40')}
                    className="px-2.5 py-1 rounded-full bg-[#282f40] text-white text-[10px] font-black"
                  >
                    #282f40 (Slate)
                  </button>
                </div>
              </div>
            </div>

            {/* Section 2: Accent Colors */}
            <div className="pt-6 border-t border-white/10 space-y-4">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Colores de Acento e Interacción</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-5 rounded-2xl space-y-3">
                  <label className="text-xs font-black text-white block uppercase tracking-wider">
                    Acento Primario (Brand Accent):
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={primaryColor}
                      onChange={(e) => applyPrimaryColor(e.target.value)}
                      className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={primaryColor}
                      onChange={(e) => applyPrimaryColor(e.target.value)}
                      className="hs-input-hero py-2 text-xs font-mono font-bold"
                    />
                  </div>
                  <div className="flex items-center gap-2 pt-1 flex-wrap">
                    <button onClick={() => applyPrimaryColor('#00dfdf')} className="px-2.5 py-0.5 rounded-full bg-[#00dfdf] text-black text-[10px] font-black">
                      #00dfdf (Cyan)
                    </button>
                    <button onClick={() => applyPrimaryColor('#38bdf8')} className="px-2.5 py-0.5 rounded-full bg-[#38bdf8] text-black text-[10px] font-black">
                      #38bdf8 (Ice)
                    </button>
                  </div>
                </div>

                <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-5 rounded-2xl space-y-3">
                  <label className="text-xs font-black text-white block uppercase tracking-wider">
                    Acento Secundario (Support Accent):
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={accentPurple}
                      onChange={(e) => applySecondaryColor(e.target.value)}
                      className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={accentPurple}
                      onChange={(e) => applySecondaryColor(e.target.value)}
                      className="hs-input-hero py-2 text-xs font-mono font-bold"
                    />
                  </div>
                  <div className="flex items-center gap-2 pt-1 flex-wrap">
                    <button onClick={() => applySecondaryColor('#a9aeb2')} className="px-2.5 py-0.5 rounded-full bg-[#a9aeb2] text-black text-[10px] font-black">
                      #a9aeb2 (Silver)
                    </button>
                  </div>
                </div>

                <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-5 rounded-2xl space-y-3">
                  <label className="text-xs font-black text-white block uppercase tracking-wider">
                    Color de Texto Principal:
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={textColor}
                      onChange={(e) => applyTextColor(e.target.value)}
                      className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={textColor}
                      onChange={(e) => applyTextColor(e.target.value)}
                      className="hs-input-hero py-2 text-xs font-mono font-bold"
                    />
                  </div>
                  <div className="flex items-center gap-2 pt-1 flex-wrap">
                    <button onClick={() => applyTextColor('#ffffff')} className="px-2.5 py-0.5 rounded-full bg-black text-white text-[10px] font-black">
                      Blanco (#ffffff)
                    </button>
                    <button onClick={() => applyTextColor('#0f172a')} className="px-2.5 py-0.5 rounded-full bg-[#0f172a] text-white text-[10px] font-black">
                      Dark (#0f172a)
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: BRANDING & LOGO */}
      {activeTab === 'branding' && (
        <div className="space-y-8 animate-fadeIn">
          <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-8 rounded-[28px] space-y-6">
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <ImageIcon style={{ color: 'var(--primary-color)' }} className="w-5 h-5" />
              <span>Identidad Visual de la Empresa (SaaS Multi-Tenant)</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-300 block uppercase tracking-wider">
                  Nombre de la Empresa / Cliente SaaS:
                </label>
                <input
                  type="text"
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  className="w-full hs-input-hero"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-slate-300 block uppercase tracking-wider">
                  URL del Logo Oficial SVG / PNG:
                </label>
                <input
                  type="text"
                  value={brandLogo}
                  onChange={(e) => setBrandLogo(e.target.value)}
                  className="w-full hs-input-hero"
                />
              </div>
            </div>

            {/* Logo Preview */}
            <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-6 rounded-2xl space-y-3">
              <span className="text-xs font-black text-slate-400 block uppercase tracking-wider">
                Vista Previa del Logo Corporativo
              </span>
              <div className="p-4 bg-black/60 rounded-xl inline-block border border-white/10">
                <img
                  src={brandLogo || '/logo.png'}
                  alt="Logo Preview"
                  className="h-12 w-auto object-contain brightness-0 invert"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PROVEEDORES DE IA & API KEYS */}
      {activeTab === 'ai-keys' && (
        <div className="space-y-8 animate-fadeIn">
          <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-8 rounded-[28px] space-y-6">
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <Key style={{ color: 'var(--primary-color)' }} className="w-5 h-5" />
              <span>Gestión de API Keys Multi-Fuente</span>
            </h2>

            <div className="space-y-4">
              <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-5 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-white flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-emerald-400" />
                    <span>OpenAI API Key (GPT-4o & Búsqueda Profunda):</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowKeys(!showKeys)}
                    className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-bold"
                  >
                    {showKeys ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showKeys ? 'Ocultar' : 'Mostrar'}</span>
                  </button>
                </div>

                <input
                  type={showKeys ? 'text' : 'password'}
                  value={openaiKey}
                  onChange={(e) => setOpenaiKey(e.target.value)}
                  className="w-full hs-input-hero font-mono text-xs"
                  placeholder="sk-..."
                />
              </div>

              {/* Test Connection Button */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={testStatus?.loading}
                  className="hs-pill-btn hs-btn-lime py-2.5 px-6 text-xs font-black flex items-center gap-2"
                >
                  <Zap className="w-4 h-4" />
                  <span>{testStatus?.loading ? 'Probando Conexión...' : 'Probar Conexión (Ping API)'}</span>
                </button>

                {testStatus && !testStatus.loading && (
                  <div
                    className={`text-xs font-bold px-4 py-2 rounded-full flex items-center gap-2 ${
                      testStatus.success
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{testStatus.msg}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Save Button Bar */}
      <div className="pt-4 border-t border-white/10 flex justify-end">
        <button
          type="button"
          onClick={handleSave}
          className="hs-pill-btn hs-btn-lime py-3 px-8 text-sm font-black shadow-2xl flex items-center gap-2"
        >
          <Check className="w-4 h-4" />
          <span>Guardar Configuración de Tema</span>
        </button>
      </div>
    </div>
  );
};
