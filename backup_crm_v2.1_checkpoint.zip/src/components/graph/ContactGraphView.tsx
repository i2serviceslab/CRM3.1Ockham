'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Contact, Relationship } from '@/types/crm';
import { Network, Plus, Search, Sparkles, User, ArrowRight, Link as LinkIcon, RefreshCw, ZoomIn, ZoomOut, Move } from 'lucide-react';

interface ContactGraphViewProps {
  contacts: Contact[];
  onOpen360: (contact: Contact) => void;
  onRefresh: () => void;
}

interface PhysicsNode {
  id: string;
  contact: Contact;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
}

export const ContactGraphView: React.FC<ContactGraphViewProps> = ({ contacts, onOpen360, onRefresh }) => {
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [selectedNode, setSelectedNode] = useState<Contact | null>(null);
  const [hoveredNode, setHoveredNode] = useState<Contact | null>(null);
  const [showAddRelModal, setShowAddRelModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Form State
  const [sourceId, setSourceId] = useState('');
  const [targetId, setTargetId] = useState('');
  const [relType, setRelType] = useState('Referido por');
  const [notes, setNotes] = useState('');
  const [loadingRel, setLoadingRel] = useState(false);

  // Pan & Zoom Navigation State
  const [zoomLevel, setZoomLevel] = useState(1);
  const transformRef = useRef({ x: 0, y: 0, zoom: 1 });

  // Canvas & Physics Engine Refs
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const nodesRef = useRef<PhysicsNode[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const draggedNodeRef = useRef<PhysicsNode | null>(null);
  const isPanDraggingRef = useRef(false);
  const panStartRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    fetchRelationships();
  }, []);

  const fetchRelationships = async () => {
    try {
      const res = await fetch('/api/relationships');
      const data = await res.json();
      if (data.success) {
        setRelationships(data.relationships);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateRelationship = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceId || !targetId || sourceId === targetId) {
      alert('Selecciona dos contactos válidos y diferentes para conectar.');
      return;
    }

    setLoadingRel(true);
    try {
      const res = await fetch('/api/relationships', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceContactId: sourceId,
          targetContactId: targetId,
          relationshipType: relType,
          notes,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setShowAddRelModal(false);
        setSourceId('');
        setTargetId('');
        setNotes('');
        fetchRelationships();
        onRefresh();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingRel(false);
    }
  };

  const filteredContacts = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.company?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.investorType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Initialize Physics Nodes with generous spacing
  useEffect(() => {
    const width = 800;
    const height = 550;

    nodesRef.current = filteredContacts.map((c, index) => {
      const existing = nodesRef.current.find((n) => n.id === c.id);
      if (existing) return { ...existing, contact: c };

      const angle = (index / (filteredContacts.length || 1)) * 2 * Math.PI;
      const dist = 160 + (index % 3) * 60;

      return {
        id: c.id,
        contact: c,
        x: width / 2 + Math.cos(angle) * dist,
        y: height / 2 + Math.sin(angle) * dist,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        radius: 26,
      };
    });
  }, [filteredContacts]);

  // Main Physics Simulation & Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const updateSize = () => {
      if (canvas && canvas.parentElement) {
        const rect = canvas.parentElement.getBoundingClientRect();
        canvas.width = rect.width || 800;
        canvas.height = 520;
      }
    };
    updateSize();
    window.addEventListener('resize', updateSize);

    const updatePhysics = () => {
      const width = canvas.width;
      const height = canvas.height;
      const nodes = nodesRef.current;

      const primaryColor =
        typeof window !== 'undefined'
          ? getComputedStyle(document.documentElement)
              .getPropertyValue('--primary-color')
              .trim() || '#38bdf8'
          : '#38bdf8';

      // 1. Repulsive forces between nodes
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const n1 = nodes[i];
          const n2 = nodes[j];
          const dx = n2.x - n1.x;
          const dy = n2.y - n1.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;

          if (dist < 260) {
            const force = ((260 - dist) / dist) * 0.09;
            const fx = dx * force;
            const fy = dy * force;

            if (n1 !== draggedNodeRef.current) {
              n1.vx -= fx;
              n1.vy -= fy;
            }
            if (n2 !== draggedNodeRef.current) {
              n2.vx += fx;
              n2.vy += fy;
            }
          }
        }
      }

      // 2. Spring attraction along relationship edges
      relationships.forEach((rel) => {
        const source = nodes.find((n) => n.id === rel.sourceContactId);
        const target = nodes.find((n) => n.id === rel.targetContactId);

        if (source && target) {
          const dx = target.x - source.x;
          const dy = target.y - source.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const desiredDist = 160;
          const force = (dist - desiredDist) * 0.004;

          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;

          if (source !== draggedNodeRef.current) {
            source.vx += fx;
            source.vy += fy;
          }
          if (target !== draggedNodeRef.current) {
            target.vx -= fx;
            target.vy -= fy;
          }
        }
      });

      // 3. Central gravity & movement damping
      nodes.forEach((n) => {
        if (n === draggedNodeRef.current) return;

        n.vx += (width / 2 - n.x) * 0.0006;
        n.vy += (height / 2 - n.y) * 0.0006;

        n.vx *= 0.90;
        n.vy *= 0.90;

        n.vx += (Math.random() - 0.5) * 0.1;
        n.vy += (Math.random() - 0.5) * 0.1;

        n.x += n.vx;
        n.y += n.vy;
      });

      // 4. Render Frame with Pan & Zoom Transform
      ctx.clearRect(0, 0, width, height);

      ctx.save();
      const panX = transformRef.current.x;
      const panY = transformRef.current.y;
      const zoom = transformRef.current.zoom;

      ctx.translate(panX, panY);
      ctx.scale(zoom, zoom);

      // Render Mesh Grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1 / zoom;
      const gridSize = 50;
      for (let x = -width * 2; x < width * 3; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, -height * 2);
        ctx.lineTo(x, height * 3);
        ctx.stroke();
      }
      for (let y = -height * 2; y < height * 3; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(-width * 2, y);
        ctx.lineTo(width * 3, y);
        ctx.stroke();
      }

      // Render Relationship Edges
      relationships.forEach((rel) => {
        const source = nodes.find((n) => n.id === rel.sourceContactId);
        const target = nodes.find((n) => n.id === rel.targetContactId);

        if (source && target) {
          const isSelected = selectedNode?.id === source.id || selectedNode?.id === target.id;
          const isHovered = hoveredNode?.id === source.id || hoveredNode?.id === target.id;

          ctx.beginPath();
          ctx.moveTo(source.x, source.y);
          ctx.lineTo(target.x, target.y);

          if (isSelected || isHovered) {
            ctx.strokeStyle = primaryColor;
            ctx.lineWidth = 3 / zoom;
            ctx.shadowColor = primaryColor;
            ctx.shadowBlur = 12;
          } else {
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
            ctx.lineWidth = 1.5 / zoom;
            ctx.shadowBlur = 0;
          }

          ctx.stroke();
          ctx.shadowBlur = 0;

          // Edge Label Pill
          const midX = (source.x + target.x) / 2;
          const midY = (source.y + target.y) / 2;

          ctx.fillStyle = '#0f1218';
          ctx.strokeStyle = isSelected || isHovered ? primaryColor : 'rgba(255, 255, 255, 0.18)';
          ctx.lineWidth = 1 / zoom;

          ctx.beginPath();
          ctx.roundRect(midX - 44, midY - 11, 88, 22, 11);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = isSelected || isHovered ? primaryColor : '#94a3b8';
          ctx.font = '900 10px Urbanist, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(rel.relationshipType, midX, midY + 1);
        }
      });

      // Render Physics Nodes
      nodes.forEach((n) => {
        const isSelected = selectedNode?.id === n.id;
        const isHovered = hoveredNode?.id === n.id;

        // Outer Glow Aura
        if (isSelected || isHovered) {
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.radius + 10, 0, 2 * Math.PI);
          ctx.fillStyle = isSelected ? `${primaryColor}44` : 'rgba(255, 255, 255, 0.12)';
          ctx.fill();
        }

        // Main Circle
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius, 0, 2 * Math.PI);
        ctx.fillStyle = isSelected ? primaryColor : '#151922';
        ctx.strokeStyle = isSelected || isHovered ? primaryColor : 'rgba(255, 255, 255, 0.25)';
        ctx.lineWidth = isSelected ? 3.5 / zoom : 2 / zoom;
        ctx.shadowColor = isSelected ? primaryColor : 'transparent';
        ctx.shadowBlur = isSelected ? 18 : 0;
        ctx.fill();
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Avatar Letter
        ctx.fillStyle = isSelected ? '#09090b' : '#ffffff';
        ctx.font = '900 15px Urbanist, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(n.contact.name.charAt(0), n.x, n.y - 1);

        // Contact Name Label
        ctx.fillStyle = isSelected ? primaryColor : '#ffffff';
        ctx.font = '800 12px Urbanist, sans-serif';
        ctx.fillText(n.contact.name, n.x, n.y + n.radius + 16);

        // Company Sub-label
        ctx.fillStyle = '#94a3b8';
        ctx.font = '600 10px Urbanist, sans-serif';
        ctx.fillText(n.contact.company || 'Inversor', n.x, n.y + n.radius + 29);
      });

      ctx.restore();

      animFrameRef.current = requestAnimationFrame(updatePhysics);
    };

    animFrameRef.current = requestAnimationFrame(updatePhysics);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', updateSize);
    };
  }, [relationships, selectedNode, hoveredNode]);

  // Precise Canvas Coordinate Converter (Converts screen mouse pixels to graph space coordinates)
  const getGraphCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0, mouseX: 0, mouseY: 0 };
    const rect = canvas.getBoundingClientRect();

    const scaleX = canvas.width / (rect.width || 1);
    const scaleY = canvas.height / (rect.height || 1);

    const mouseX = (e.clientX - rect.left) * scaleX;
    const mouseY = (e.clientY - rect.top) * scaleY;

    const graphX = (mouseX - transformRef.current.x) / transformRef.current.zoom;
    const graphY = (mouseY - transformRef.current.y) / transformRef.current.zoom;

    return { x: graphX, y: graphY, mouseX, mouseY };
  };

  // Mouse Down Event Handler
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const { x, y, mouseX, mouseY } = getGraphCoords(e);

    // Hit test with generous radius (+12px) for easy clicking and touch
    const clicked = nodesRef.current.find((n) => {
      const dx = n.x - x;
      const dy = n.y - y;
      return Math.sqrt(dx * dx + dy * dy) <= n.radius + 12;
    });

    if (clicked) {
      draggedNodeRef.current = clicked;
      setSelectedNode(clicked.contact);
    } else {
      // Pan canvas background
      isPanDraggingRef.current = true;
      panStartRef.current = {
        x: mouseX - transformRef.current.x,
        y: mouseY - transformRef.current.y,
      };
    }
  };

  // Mouse Move Event Handler
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const { x, y, mouseX, mouseY } = getGraphCoords(e);

    if (draggedNodeRef.current) {
      draggedNodeRef.current.x = x;
      draggedNodeRef.current.y = y;
      draggedNodeRef.current.vx = 0;
      draggedNodeRef.current.vy = 0;
    } else if (isPanDraggingRef.current) {
      transformRef.current.x = mouseX - panStartRef.current.x;
      transformRef.current.y = mouseY - panStartRef.current.y;
    } else {
      const hovered = nodesRef.current.find((n) => {
        const dx = n.x - x;
        const dy = n.y - y;
        return Math.sqrt(dx * dx + dy * dy) <= n.radius + 12;
      });
      setHoveredNode(hovered ? hovered.contact : null);
      canvas.style.cursor = hovered ? 'pointer' : isPanDraggingRef.current ? 'grabbing' : 'grab';
    }
  };

  // Mouse Up Event Handler
  const handleMouseUp = () => {
    draggedNodeRef.current = null;
    isPanDraggingRef.current = false;
  };

  // Wheel Zoom Event Handler
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
    const newZoom = Math.max(0.4, Math.min(2.5, transformRef.current.zoom * zoomFactor));

    transformRef.current.zoom = newZoom;
    setZoomLevel(Math.round(newZoom * 100));
  };

  // Zoom Button Controls
  const handleZoom = (delta: number) => {
    const newZoom = Math.max(0.4, Math.min(2.5, transformRef.current.zoom + delta));
    transformRef.current.zoom = newZoom;
    setZoomLevel(Math.round(newZoom * 100));
  };

  const handleResetView = () => {
    transformRef.current = { x: 0, y: 0, zoom: 1 };
    setZoomLevel(100);
  };

  return (
    <div className="space-y-6 font-['Urbanist'] w-full">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Network style={{ color: 'var(--primary-color)' }} className="w-5 h-5" />
            <span>Interactive Relationship Graph & Physics Simulation</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 font-medium">
            Interactive physics mesh. Drag nodes to move them and drag background to pan the network space.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative w-60">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search in graph..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-[#151922] border border-white/10 rounded-full text-xs text-white focus:outline-none"
            />
          </div>

          <button
            onClick={() => setShowAddRelModal(true)}
            className="hs-pill-btn hs-btn-lime py-2 px-4 text-xs font-black shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Link Relationship</span>
          </button>
        </div>
      </div>

      {/* Main Canvas & Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* HTML5 Canvas Interactive Space */}
        <div className="lg:col-span-2 hs-super-card p-6 min-h-[540px] relative overflow-hidden bg-[#151922] border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 border-b border-white/5 pb-3">
            <span className="flex items-center gap-2 font-bold" style={{ color: 'var(--primary-color)' }}>
              <span
                style={{ backgroundColor: 'var(--primary-color)' }}
                className="w-2 h-2 rounded-full animate-ping"
              />
              LIVE PHYSICS NETWORK & NAVIGATION
            </span>

            {/* Zoom Controls Overlay */}
            <div className="flex items-center gap-2 bg-[#0f1218] border border-white/10 px-3 py-1 rounded-full text-[11px]">
              <button onClick={() => handleZoom(0.2)} className="hover:text-white" title="Zoom In">
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <span className="font-bold text-white min-w-[36px] text-center">{zoomLevel}%</span>
              <button onClick={() => handleZoom(-0.2)} className="hover:text-white" title="Zoom Out">
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleResetView}
                className="text-slate-400 hover:text-white border-l border-white/10 pl-2 ml-1"
                title="Center Graph"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Canvas Container with Mouse & Wheel Navigation */}
          <div className="relative w-full h-[430px] my-2 rounded-2xl overflow-hidden bg-[#0f1218] border border-white/5">
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onWheel={handleWheel}
              className="w-full h-full block cursor-grab active:cursor-grabbing"
            />
          </div>

          <div className="text-[11px] text-slate-400 text-center font-mono border-t border-white/5 pt-2 flex items-center justify-between">
            <span>🖱️ Drag any node to move | Drag background to pan | Mouse wheel to zoom.</span>
            <span className="text-[10px] text-[#38bdf8] font-bold">100% Interactive</span>
          </div>
        </div>

        {/* Node Inspector Drawer */}
        <div className="hs-super-card p-6 space-y-6 bg-[#151922] border border-white/10">
          {selectedNode ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <User style={{ color: 'var(--primary-color)' }} className="w-4 h-4" />
                  <span>Node Inspection</span>
                </h3>
                <button
                  onClick={() => onOpen360(selectedNode)}
                  style={{ color: 'var(--primary-color)' }}
                  className="text-xs hover:underline font-black flex items-center gap-1"
                >
                  <span>View 360°</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-[#0f1218] border border-white/5 space-y-2">
                <h4 className="text-base font-black text-white">{selectedNode.name}</h4>
                <p className="text-xs text-slate-400 font-medium">{selectedNode.title} at {selectedNode.company}</p>
                <div className="flex gap-2 text-xs pt-1 flex-wrap">
                  <span
                    style={{
                      backgroundColor: 'var(--primary-color-alpha)',
                      color: 'var(--primary-color)',
                      borderColor: 'var(--primary-color)',
                    }}
                    className="px-2.5 py-1 rounded-full text-[10px] font-black border"
                  >
                    {selectedNode.investorType}
                  </span>
                  <span
                    style={{
                      backgroundColor: 'var(--secondary-color-alpha)',
                      color: 'var(--secondary-color)',
                      borderColor: 'var(--secondary-color)',
                    }}
                    className="px-2.5 py-1 rounded-full text-[10px] font-black border"
                  >
                    {selectedNode.stage}
                  </span>
                </div>
              </div>

              {/* Connected Edges */}
              <div>
                <h4 className="text-xs font-black text-slate-300 mb-3 uppercase tracking-wider">
                  Direct Network Relationships
                </h4>

                <div className="space-y-2.5">
                  {relationships
                    .filter((r) => r.sourceContactId === selectedNode.id || r.targetContactId === selectedNode.id)
                    .map((rel) => {
                      const isSource = rel.sourceContactId === selectedNode.id;
                      const partner = isSource ? rel.targetContact : rel.sourceContact;

                      return (
                        <div key={rel.id} className="p-3.5 rounded-2xl bg-[#0f1218] border border-white/5 space-y-1">
                          <div className="flex items-center justify-between text-xs font-black text-white">
                            <span style={{ color: 'var(--primary-color)' }}>{rel.relationshipType}</span>
                            <span>{partner?.name || 'Contact'}</span>
                          </div>
                          {rel.notes && <p className="text-[11px] text-slate-400 font-medium">{rel.notes}</p>}
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-24 text-slate-500 space-y-3">
              <Sparkles style={{ color: 'var(--primary-color)' }} className="w-8 h-8 mx-auto animate-pulse" />
              <p className="text-xs font-medium">Click or drag any node to view live details.</p>
            </div>
          )}
        </div>
      </div>

      {/* Connect Nodes Modal */}
      {showAddRelModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md hs-super-card bg-[#151922] border border-white/10 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <LinkIcon style={{ color: 'var(--primary-color)' }} className="w-4 h-4" />
                <span>Link Relationship Between Contacts</span>
              </h3>
              <button
                onClick={() => setShowAddRelModal(false)}
                className="w-8 h-8 rounded-full bg-[#1e2430] text-slate-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateRelationship} className="space-y-3">
              <div>
                <label className="block text-xs font-black text-slate-300 mb-1">Source Contact</label>
                <select
                  value={sourceId}
                  onChange={(e) => setSourceId(e.target.value)}
                  className="w-full hs-input-hero text-xs"
                >
                  <option value="">Select contact 1...</option>
                  {contacts.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.company || 'Investor'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-300 mb-1">Relationship Type</label>
                <select
                  value={relType}
                  onChange={(e) => setRelType(e.target.value)}
                  className="w-full hs-input-hero text-xs"
                >
                  <option value="Referred by">Referred by</option>
                  <option value="Broker for">Broker for</option>
                  <option value="Co-Investor with">Co-Investor with</option>
                  <option value="Technical Advisor to">Technical Advisor to</option>
                  <option value="Strategic Partner with">Strategic Partner with</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-300 mb-1">Target Contact</label>
                <select
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full hs-input-hero text-xs"
                >
                  <option value="">Select contact 2...</option>
                  {contacts.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.company || 'Investor'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-300 mb-1">Relationship Notes</label>
                <textarea
                  rows={2}
                  placeholder="Details on how they connect..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full p-3 bg-[#0f1218] border border-white/10 rounded-2xl text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddRelModal(false)}
                  className="hs-pill-btn hs-btn-dark py-2 px-4 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loadingRel}
                  className="hs-pill-btn hs-btn-lime py-2 px-5 text-xs font-black"
                >
                  Link Nodes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
