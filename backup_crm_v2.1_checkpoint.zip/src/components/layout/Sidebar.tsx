'use client';

import React from 'react';
import {
  Users,
  Network,
  Clock,
  Mic,
  Workflow,
  MessageSquare,
  BarChart3,
  Sliders,
  Sparkles,
  Calendar,
} from 'lucide-react';

export type ActiveTab =
  | 'contacts'
  | 'graph'
  | 'followup'
  | 'voice-notes'
  | 'whatsapp'
  | 'workflows'
  | 'social-calendar'
  | 'analytics'
  | 'settings';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  contactCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, contactCount }) => {
  const menuItems = [
    { id: 'contacts' as ActiveTab, label: '360° Contacts', icon: Users, badge: contactCount },
    { id: 'graph' as ActiveTab, label: 'Relationship Graph', icon: Network, highlight: true },
    { id: 'followup' as ActiveTab, label: 'Follow-up Pipeline', icon: Clock },
    { id: 'social-calendar' as ActiveTab, label: 'Social Calendar', icon: Calendar, badge: 'IR' },
    { id: 'voice-notes' as ActiveTab, label: 'Voice Notes', icon: Mic },
    { id: 'whatsapp' as ActiveTab, label: 'WhatsApp Baileys', icon: MessageSquare, badge: 'Bot' },
    { id: 'workflows' as ActiveTab, label: 'Workflows & Rules', icon: Workflow },
    { id: 'analytics' as ActiveTab, label: 'Analytics & Reports', icon: BarChart3 },
    { id: 'settings' as ActiveTab, label: 'Branding & Theme', icon: Sliders },
  ];

  return (
    <aside className="fixed left-0 top-28 bottom-0 w-64 bg-[#090a0f] p-5 flex flex-col justify-between hidden md:flex border-r border-white/10 z-40 overflow-y-auto font-['Urbanist']">
      <div className="space-y-2">
        <div className="px-3 py-2 text-[10px] font-black tracking-widest text-slate-500 uppercase">
          WORKSPACE NAV
        </div>

        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={
                isActive
                  ? { backgroundColor: 'var(--primary-color)', color: '#09090b' }
                  : {}
              }
              className={`w-full flex items-center justify-between px-4 py-3 rounded-full text-xs font-black transition-all group ${
                isActive
                  ? 'shadow-lg shadow-black/40'
                  : 'text-slate-400 hover:text-white hover:bg-[#161822]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                    isActive
                      ? 'bg-black/10 text-zinc-950'
                      : 'bg-[#1f2330] text-slate-400 group-hover:text-white'
                  }`}
                >
                  <Icon
                    style={
                      !isActive && item.highlight
                        ? { color: 'var(--primary-color)' }
                        : {}
                    }
                    className="w-4 h-4"
                  />
                </div>
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span
                  style={
                    isActive
                      ? { backgroundColor: '#09090b', color: 'var(--primary-color)' }
                      : {
                          backgroundColor: 'var(--primary-color-alpha)',
                          color: 'var(--primary-color)',
                          borderColor: 'var(--primary-color)',
                        }
                  }
                  className="text-[10px] px-2 py-0.5 rounded-full font-black shrink-0 border border-transparent"
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Powered By i2 White Container */}
      <div className="p-3.5 rounded-2xl bg-white text-center space-y-1 mt-4 shrink-0 flex flex-col items-center justify-center shadow-lg border border-slate-200">
        <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">
          Powered by:
        </span>
        <img
          src="/i2_logo.png"
          alt="i2 Logo"
          className="h-10 w-auto object-contain max-w-[150px] py-0.5"
        />
      </div>
    </aside>
  );
};
