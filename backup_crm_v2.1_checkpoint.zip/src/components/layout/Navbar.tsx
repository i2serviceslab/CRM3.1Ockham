'use client';

import React from 'react';
import { Search, Shield, Sparkles, Video, Calendar, ArrowUpRight } from 'lucide-react';

interface NavbarProps {
  user: any;
  onLogout: () => void;
  brandName: string;
  brandLogo: string;
  onOpenThemeSettings: () => void;
  onOpenVideoCall?: () => void;
  onOpenAgenda?: () => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  totalContacts: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onLogout,
  brandName,
  brandLogo,
  onOpenThemeSettings,
  onOpenVideoCall,
  onOpenAgenda,
  searchTerm,
  setSearchTerm,
  totalContacts,
}) => {
  const currentLogo = brandLogo || '/logo.png';

  return (
    <header className="h-28 bg-[#000000] px-6 lg:px-8 flex items-center justify-between sticky top-0 z-50 border-b border-white/5 w-full font-['Urbanist']">
      {/* Left: Brand Logo + Pill Schedule Bar */}
      <div className="flex items-center gap-6 shrink-0">
        {/* Official Brand Logo */}
        <div className="flex flex-col items-start gap-1 py-1">
          <img
            src={currentLogo}
            alt="Outcrop Silver Official Logo"
            className="h-12 w-auto object-contain brightness-0 invert drop-shadow-md"
          />
          <span
            style={{ color: 'var(--primary-color)' }}
            className="text-[10px] font-black uppercase tracking-widest leading-none pt-0.5"
          >
            CORE - CRM v2.1
          </span>
        </div>

        {/* Your Schedule Top Pill Bar */}
        <div
          onClick={onOpenAgenda}
          style={{ backgroundColor: 'var(--bg-card)' }}
          className="hidden xl:flex items-center p-1.5 rounded-full text-xs cursor-pointer transition-all shadow-lg"
        >
          <div className="px-3 py-1.5 text-white font-extrabold text-xs flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>Your Schedule</span>
          </div>

          <span style={{ backgroundColor: 'var(--bg-card-inner)' }} className="px-3 py-1 rounded-full text-slate-300 text-[11px] font-bold">
            28 March
          </span>

          {/* Active Time Slot in Solid Primary Accent Color */}
          <div
            style={{ backgroundColor: 'var(--primary-color)', color: '#000000' }}
            className="px-3 py-1 rounded-full font-extrabold text-[11px] flex items-center gap-2 shadow-md"
          >
            <div className="flex -space-x-1.5">
              <img className="w-4 h-4 rounded-full border border-black object-cover" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=80&q=80" alt="Av1" />
              <img className="w-4 h-4 rounded-full border border-black object-cover" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=80&q=80" alt="Av2" />
            </div>
            <span>2:00 pm</span>
            <ArrowUpRight className="w-3 h-3 stroke-[3]" />
          </div>

          <div className="px-3 py-1 text-slate-400 font-bold text-[11px] flex items-center gap-1.5">
            <div className="flex -space-x-1.5">
              <img className="w-4 h-4 rounded-full border border-black object-cover" src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=80&q=80" alt="Av3" />
            </div>
            <span>3:00 pm</span>
          </div>
        </div>
      </div>

      {/* Center/Right: Relationship & Contact Tracking Stat Metrics (No commercial sales terms) */}
      <div className="hidden lg:flex items-center gap-8 shrink-0">
        {/* Contact Metric 1 */}
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black text-white font-mono tracking-tight">{totalContacts || 14}</span>
          <div className="flex items-center gap-1">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Contacts</span>
            <span style={{ backgroundColor: 'var(--primary-color)', color: '#000000' }} className="text-[9px] font-black px-1.5 py-0.5 rounded-full">
              +{totalContacts || 14}
            </span>
          </div>
        </div>

        {/* Contact Metric 2 */}
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black text-white font-mono tracking-tight">20</span>
          <div className="flex items-center gap-1">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Touchpoints</span>
            <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              +4
            </span>
          </div>
        </div>

        {/* Contact Metric 3 */}
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black text-white font-mono tracking-tight">3</span>
          <div className="flex items-center gap-1">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Follow-ups</span>
            <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Due
            </span>
          </div>
        </div>
      </div>

      {/* Far Right: Circular Action Buttons & User Avatar */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenVideoCall}
          className="hs-circle-btn hs-circle-btn-lime"
          title="Start IR Video Call"
        >
          <Video className="w-4 h-4" />
        </button>

        <button
          onClick={onOpenAgenda}
          className="hs-circle-btn hs-circle-btn-dark"
          title="View Meeting Agenda"
        >
          <Calendar className="w-4 h-4" />
        </button>

        <button
          onClick={onOpenThemeSettings}
          className="hs-circle-btn hs-circle-btn-dark"
          title="Customize Branding"
        >
          <Shield className="w-4 h-4" />
        </button>

        {/* User Profile Info */}
        <div className="flex items-center gap-3 pl-3 border-l border-white/10">
          <img
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
            alt={user?.name || 'User'}
            className="w-10 h-10 rounded-full object-cover border-2"
            style={{ borderColor: 'var(--primary-color)' }}
          />
          <div className="hidden md:block text-left">
            <span className="text-xs font-black text-white block leading-none">{user?.name || 'Admin'}</span>
            <span className="text-[10px] text-slate-400 font-medium block leading-none mt-1">{user?.role || 'IR Lead'}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
