'use client';

import React, { useState } from 'react';
import { Contact } from '@/types/crm';
import {
  TrendingUp,
  Users,
  MessageSquare,
  FileText,
  Clock,
  Award,
  Globe,
  PieChart as PieIcon,
  BarChart3,
  Flame,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowUpRight,
  Filter,
  Download,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface IRMetricsDashboardProps {
  contacts: Contact[];
  onOpenContact360?: (contact: Contact) => void;
}

export const IRMetricsDashboard: React.FC<IRMetricsDashboardProps> = ({ contacts, onOpenContact360 }) => {
  const [timeframe, setTimeframe] = useState<'30D' | '90D' | 'YTD' | 'ALL'>('30D');

  // Computed metrics
  const totalContacts = contacts.length;
  const hnwCount = contacts.filter((c) => c.investorType.includes('HNW') || c.investorType.includes('Retail')).length;
  const peCount = contacts.filter((c) => c.investorType.includes('PE') || c.investorType.includes('Institutional')).length;
  const familyCount = contacts.filter((c) => c.investorType.includes('Family') || c.investorType.includes('Office')).length;
  const advisorCount = totalContacts - (hnwCount + peCount + familyCount);

  // Engagement calculation
  const totalScore = contacts.reduce((acc, c) => acc + (c.leadScore || 70), 0);
  const avgScore = totalContacts > 0 ? Math.round(totalScore / totalContacts) : 75;

  return (
    <div className="space-y-6 font-['Urbanist'] w-full animate-fadeIn">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white uppercase tracking-tight flex items-center gap-2">
              <BarChart3 style={{ color: 'var(--primary-color)' }} className="w-5 h-5" />
              <span>Panel de Inteligencia & Métricas IR Outcrop</span>
            </h2>
            <span
              style={{ backgroundColor: 'var(--primary-color)', color: '#000000' }}
              className="px-2.5 py-0.5 rounded-full font-black text-[10px] uppercase shadow-md"
            >
              RELACIONES DE INVERSIÓN
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-medium">
            Análisis cualitativo y cuantitativo del relacionamiento con inversionistas, frecuencia de interacciones y distribución de reportes técnicos de Santa Ana.
          </p>
        </div>

        {/* Timeframe selector */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-1 rounded-full flex items-center gap-1 border border-white/5 shrink-0">
          {(['30D', '90D', 'YTD', 'ALL'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTimeframe(t)}
              style={
                timeframe === t
                  ? { backgroundColor: 'var(--primary-color)', color: '#000000' }
                  : {}
              }
              className={`px-3 py-1 rounded-full text-xs font-black transition-all ${
                timeframe === t ? 'shadow-md scale-105' : 'text-slate-400 hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* SECTION 1: EXECUTIVE KPI BAR (ZERO E-COMMERCE / ZERO SALES METRICS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* KPI 1: Stakeholders Activos */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-4 rounded-[24px] border border-white/5 space-y-1 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Inversionistas</span>
            <Users className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{totalContacts}</div>
          <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> +12% este trimestre
          </p>
        </div>

        {/* KPI 2: Interacciones / Touchpoints */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-4 rounded-[24px] border border-white/5 space-y-1 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Interacciones IR</span>
            <MessageSquare className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">148</div>
          <p className="text-[10px] text-slate-400 font-medium">Notas de voz & reuniones</p>
        </div>

        {/* KPI 3: Ensayos Técnicos Entregados */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-4 rounded-[24px] border border-white/5 space-y-1 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Reportes Santa Ana</span>
            <FileText className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">64</div>
          <p className="text-[10px] text-slate-400 font-medium">Briefs técnicos enviados</p>
        </div>

        {/* KPI 4: Lead Score Promedio */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-4 rounded-[24px] border border-white/5 space-y-1 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Score Engagement</span>
            <Award style={{ color: 'var(--primary-color)' }} className="w-4 h-4" />
          </div>
          <div style={{ color: 'var(--primary-color)' }} className="text-2xl font-black font-mono">
            {avgScore} pts
          </div>
          <p className="text-[10px] text-emerald-400 font-bold">Interés Alto / Calificado</p>
        </div>

        {/* KPI 5: SLA de Respuesta */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-4 rounded-[24px] border border-white/5 space-y-1 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tiempo Respuesta</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">1.4 Hrs</div>
          <p className="text-[10px] text-slate-400 font-medium">Promedio de respuesta IR</p>
        </div>
      </div>

      {/* SECTION 2: DEMOGRAPHICS & GEOGRAPHIC DISTRIBUTION GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Investor Composition Breakdown */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-6 rounded-[28px] border border-white/5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-sky-400" />
              <span>Composición de la Red de Inversionistas</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono font-bold">Por Tipo de Fondo / Entidad</span>
          </div>

          <div className="space-y-3">
            {/* PE Funds Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-300">Fondos de Capital Minero (PE)</span>
                <span className="text-white font-mono">42% ({peCount > 0 ? peCount : 4} fondos)</span>
              </div>
              <div className="w-full bg-white/5 rounded-full h-2.5 overflow-hidden">
                <div style={{ backgroundColor: 'var(--primary-color)' }} className="h-full rounded-full w-[42%]" />
              </div>
            </div>

            {/* Family Offices Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-300">Family Offices & Multi-Family</span>
                <span className="text-white font-mono">28% ({familyCount > 0 ? familyCount : 3} entidades)</span>
              </div>
              <div className="w-full bg-white/5 rounded-full h-2.5 overflow-hidden">
                <div className="bg-emerald-400 h-full rounded-full w-[28%]" />
              </div>
            </div>

            {/* HNW Accredited Retail Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-300">Inversionistas Acreditados (HNW Retail)</span>
                <span className="text-white font-mono">18% ({hnwCount > 0 ? hnwCount : 2} personas)</span>
              </div>
              <div className="w-full bg-white/5 rounded-full h-2.5 overflow-hidden">
                <div className="bg-amber-400 h-full rounded-full w-[18%]" />
              </div>
            </div>

            {/* Advisors Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-300">Asesores Geológicos & Mercado de Capitales</span>
                <span className="text-white font-mono">12% ({advisorCount > 0 ? advisorCount : 2} consultores)</span>
              </div>
              <div className="w-full bg-white/5 rounded-full h-2.5 overflow-hidden">
                <div className="bg-purple-400 h-full rounded-full w-[12%]" />
              </div>
            </div>
          </div>
        </div>

        {/* Geographic Investor Hubs */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-6 rounded-[28px] border border-white/5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>Distribución Geográfica de Capital IR</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono font-bold">Hubs Mineros</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-white">🇨🇦 Vancouver & Toronto</span>
                <span className="text-xs font-mono font-black text-sky-400">45%</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Principal hub de fondos de minería en Canadá.</p>
            </div>

            <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-white">🇺🇸 New York & Boston</span>
                <span className="text-xs font-mono font-black text-emerald-400">30%</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Institucionales y Private Equity de EE. UU.</p>
            </div>

            <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-white">🇬🇧 Londres & Europa</span>
                <span className="text-xs font-mono font-black text-amber-400">15%</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Bolsa de Valores e Inversionistas de Reino Unido.</p>
            </div>

            <div style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-4 rounded-2xl space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-white">🇨🇴 Colombia & LatAm</span>
                <span className="text-xs font-mono font-black text-purple-400">10%</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Aliados regionales del proyecto Santa Ana.</p>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 3: PIPELINE VELOCITY & INTERACTION TIMELINE */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* IR Pipeline Funnel Velocity */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-6 rounded-[28px] border border-white/5 space-y-4 shadow-xl lg:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Zap style={{ color: 'var(--primary-color)' }} className="w-4 h-4" />
              <span>Velocidad de Conversación en el Flujo de Seguimiento</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono font-bold">Etapas IR</span>
          </div>

          <div className="space-y-2.5">
            {[
              { stage: 'Primer Contacto', count: contacts.length, percentage: 100, color: 'bg-sky-500' },
              { stage: 'Presentación / Deck Enviado', count: Math.max(1, Math.round(contacts.length * 0.75)), percentage: 75, color: 'bg-purple-500' },
              { stage: 'Reunión Agendada', count: Math.max(1, Math.round(contacts.length * 0.5)), percentage: 50, color: 'bg-amber-500' },
              { stage: 'Seguimiento Pendiente', count: Math.max(1, Math.round(contacts.length * 0.35)), percentage: 35, color: 'bg-emerald-500' },
              { stage: 'Decisión Tomada / Aliado Estratégico', count: Math.max(1, Math.round(contacts.length * 0.2)), percentage: 20, color: 'bg-teal-400' },
            ].map((item, idx) => (
              <div key={idx} style={{ backgroundColor: 'var(--bg-card-inner)' }} className="p-3 rounded-2xl space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-200">{item.stage}</span>
                  <span className="text-white font-mono">{item.count} contactos ({item.percentage}%)</span>
                </div>
                <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
                  <div className={`h-full rounded-full ${item.color}`} style={{ width: `${item.percentage}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Engagement Contacts Feed */}
        <div style={{ backgroundColor: 'var(--bg-card)' }} className="p-6 rounded-[28px] border border-white/5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-500" />
              <span>Inversionistas con Mayor Score</span>
            </h3>
          </div>

          <div className="space-y-3">
            {contacts.slice(0, 4).map((c) => (
              <div
                key={c.id}
                onClick={() => onOpenContact360 && onOpenContact360(c)}
                style={{ backgroundColor: 'var(--bg-card-inner)' }}
                className="p-3 rounded-2xl flex items-center justify-between cursor-pointer hover:border-white/20 border border-transparent transition-all group"
              >
                <div className="min-w-0 flex-1">
                  <h4 className="text-xs font-black text-white group-hover:text-sky-400 transition-colors truncate">
                    {c.name}
                  </h4>
                  <p className="text-[10px] text-slate-400 font-medium truncate">
                    {c.company || 'Inversor Minero'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    style={{ backgroundColor: 'var(--primary-color)', color: '#000000' }}
                    className="px-2.5 py-0.5 rounded-full text-[10px] font-black font-mono shadow-md"
                  >
                    {c.leadScore || 85} pts
                  </span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-white transition-colors" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
