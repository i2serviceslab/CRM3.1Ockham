'use client';

import React, { useRef, useState, useEffect, useId } from 'react';

interface ConcaveCardProps {
  children: React.ReactNode;
  className?: string;
  bgColor?: string;
  notchWidth?: number; // width in px of top-right notch cutout
  notchHeight?: number; // height in px of top-right notch cutout
  actionButton?: React.ReactNode;
}

export const ConcaveCard: React.FC<ConcaveCardProps> = ({
  children,
  className = '',
  bgColor = 'var(--bg-card)',
  notchWidth = 52,
  notchHeight = 52,
  actionButton,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 320, h: 220 });
  const rawId = useId();
  const clipId = `concave-clip-${rawId.replace(/[^a-zA-Z0-9_-]/g, '')}`;

  useEffect(() => {
    if (!containerRef.current) return;

    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          setSize({ w: rect.width, h: rect.height });
        }
      }
    };

    updateSize();

    const observer = new ResizeObserver(() => {
      updateSize();
    });

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Quadratic Bezier Vector SVG Path Generator for Silky Smooth Concave Notches
  const generatePathD = (W: number, H: number, NW: number, NH: number) => {
    if (!actionButton || NW <= 0 || NH <= 0) {
      const R = 28;
      return `M 0,${R} A ${R},${R} 0 0 1 ${R},0 L ${W - R},0 A ${R},${R} 0 0 1 ${W},${R} L ${W},${H - R} A ${R},${R} 0 0 1 ${W - R},${H} L ${R},${H} A ${R},${R} 0 0 1 0,${H - R} Z`;
    }

    const R = 28; // Main outer corner radius
    const f = 14; // Smooth fillet curve radius

    const x1 = W - NW - f;
    const x2 = W - NW;
    const x3 = W - NW + f;
    const y1 = NH - f;
    const y2 = NH;
    const y3 = NH + f;

    return `
      M 0,${R}
      A ${R},${R} 0 0 1 ${R},0
      L ${x1},0
      Q ${x2},0 ${x2},${f}
      L ${x2},${y1}
      Q ${x2},${y2} ${x3},${y2}
      L ${W - f},${y2}
      Q ${W},${y2} ${W},${y3}
      L ${W},${H - R}
      A ${R},${R} 0 0 1 ${W - R},${H}
      L ${R},${H}
      A ${R},${R} 0 0 1 0,${H - R}
      Z
    `;
  };

  const pathD = generatePathD(size.w, size.h, notchWidth, notchHeight);

  return (
    <div ref={containerRef} className={`relative group transition-all ${className}`}>
      {/* SVG Background Fill and ClipPath definition */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none drop-shadow-xl overflow-visible z-0"
        width={size.w}
        height={size.h}
        viewBox={`0 0 ${size.w} ${size.h}`}
      >
        <defs>
          <clipPath id={clipId} clipPathUnits="userSpaceOnUse">
            <path d={pathD} />
          </clipPath>
        </defs>
        <path
          d={pathD}
          fill={bgColor}
          stroke="none"
        />
      </svg>

      {/* Action Button Floating in transparent Notch space */}
      {actionButton && (
        <div
          style={{ width: `${notchWidth}px`, height: `${notchHeight}px` }}
          className="absolute top-0 right-0 flex items-center justify-center z-30 pointer-events-auto"
        >
          {actionButton}
        </div>
      )}

      {/* Card Content Body - Positioned inset-0 and clipped by exact SVG path */}
      <div
        className="relative z-10 w-full h-full p-6"
        style={{ clipPath: `url(#${clipId})` }}
      >
        {children}
      </div>
    </div>
  );
};
