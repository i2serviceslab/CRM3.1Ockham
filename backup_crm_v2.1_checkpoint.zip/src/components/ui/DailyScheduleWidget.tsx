'use client';

import React from 'react';
import { Calendar, ArrowUpRight, Plus, ArrowLeft } from 'lucide-react';

interface DailyScheduleWidgetProps {
  onOpenAgenda: () => void;
}

export const DailyScheduleWidget: React.FC<DailyScheduleWidgetProps> = ({ onOpenAgenda }) => {
  return (
    <div
      onClick={onOpenAgenda}
      className="relative rounded-[32px] overflow-hidden cursor-pointer group shadow-2xl transition-transform hover:scale-[1.01] flex flex-col justify-between"
      style={{ backgroundColor: 'var(--primary-color)' }}
    >
      {/* Top Black Header Container with Organic Curved Wave */}
      <div className="bg-[#121214] text-white p-6 pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#242428] text-white flex items-center justify-center border border-white/10">
              <ArrowLeft className="w-4 h-4" />
            </div>
            <span className="text-xl font-black tracking-tight text-white">Daily Schedule</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#242428] text-white flex items-center justify-center border border-white/10">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="w-8 h-8 rounded-full bg-[#242428] text-white flex items-center justify-center border border-white/10">
              <Plus className="w-4 h-4" />
            </div>
          </div>
        </div>

        <div className="flex items-baseline gap-1.5 pt-3 pl-11">
          <span className="text-3xl font-black text-white font-mono">28</span>
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">MARCH</span>
        </div>
      </div>

      {/* Seamless Organic Wave Divider (Sloping down to the right for icon breathing room) */}
      <div className="w-full h-10 bg-[#121214] leading-none overflow-hidden -mt-1">
        <svg
          className="w-full h-full block text-[var(--primary-color)]"
          viewBox="0 0 400 40"
          preserveAspectRatio="none"
        >
          <path d="M 0,40 C 180,40 240,0 400,0 L 400,40 L 0,40 Z" fill="currentColor" />
        </svg>
      </div>

      {/* Solid Bold Accent Body with Time Slots */}
      <div className="p-6 pt-2 text-[#000000] space-y-3">
        {/* Slot 1 */}
        <div className="p-4 rounded-3xl bg-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-4">
            <div className="text-2xl font-black font-mono text-black">
              2 <span className="text-xs font-black uppercase">PM</span>
            </div>
            <div className="flex -space-x-2">
              <img
                className="w-8 h-8 rounded-full border-2 border-white object-cover"
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                alt="Av1"
              />
              <img
                className="w-8 h-8 rounded-full border-2 border-white object-cover"
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80"
                alt="Av2"
              />
            </div>
          </div>

          <span className="px-4 py-1.5 rounded-full bg-[#121214] text-white text-xs font-black">
            36 min
          </span>
        </div>

        {/* Slot 2 */}
        <div className="p-4 rounded-3xl bg-black/15 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-2xl font-black font-mono text-black">
              4 <span className="text-xs font-black uppercase">PM</span>
            </div>
            <div className="flex -space-x-2">
              <img
                className="w-8 h-8 rounded-full border-2 border-black object-cover"
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&q=80"
                alt="Av3"
              />
            </div>
          </div>

          <span className="text-xs font-black text-black flex items-center gap-1">
            <span>Roadshow Call</span>
            <ArrowUpRight className="w-4 h-4 stroke-[3] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </span>
        </div>
      </div>
    </div>
  );
};
