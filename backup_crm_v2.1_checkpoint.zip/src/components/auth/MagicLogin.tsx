'use client';

import React, { useState } from 'react';
import { Mail, KeyRound, Sparkles, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface MagicLoginProps {
  onLoginSuccess: (user: any) => void;
  brandName: string;
}

export const MagicLogin: React.FC<MagicLoginProps> = ({ onLoginSuccess, brandName }) => {
  const [email, setEmail] = useState('admin@outcropsilver.com');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'EMAIL' | 'CODE'>('EMAIL');
  const [loading, setLoading] = useState(false);
  const [previewCode, setPreviewCode] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/magic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'REQUEST_CODE', email }),
      });
      const data = await res.json();

      if (data.success) {
        setPreviewCode(data.previewCode);
        setStep('CODE');
      } else {
        setError(data.error || 'Error al generar código');
      }
    } catch (err: any) {
      setError('Error de conexión con el servidor de autenticación');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/magic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'VERIFY_CODE', email, code }),
      });
      const data = await res.json();

      if (data.success) {
        onLoginSuccess(data.user);
      } else {
        setError(data.error || 'Código inválido');
      }
    } catch (err: any) {
      setError('Error de conexión al verificar PIN');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#141523] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Dynamic Glowing Accents */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none animate-pulse" />

      <div className="w-full max-w-md bg-[#1f2138] border border-white/10 rounded-3xl p-8 shadow-2xl shadow-black/80 relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center mx-auto mb-4 shadow-xl shadow-blue-500/30">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">{brandName}</h2>
          <p className="text-xs text-slate-400 mt-1">Acceso seguro mediante correo electrónico (Magic PIN)</p>
        </div>

        {error && (
          <div className="mb-6 p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs text-center font-medium">
            {error}
          </div>
        )}

        {step === 'EMAIL' ? (
          <form onSubmit={handleRequestCode} className="space-y-5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">Correo Electrónico Corporativo</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ejemplo@outcropsilver.com"
                  className="w-full pl-11 pr-4 py-3 bg-[#141523] border border-white/10 rounded-2xl text-sm text-white focus:outline-none focus:border-blue-500 transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {loading ? 'Generando PIN...' : 'Enviar Código Magic Link'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyCode} className="space-y-5">
            {/* Simulation Preview Box */}
            {previewCode && (
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center mb-4">
                <div className="flex items-center justify-center gap-2 text-emerald-400 text-xs font-semibold mb-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simulación de Correo Recibido</span>
                </div>
                <div className="text-2xl font-mono font-bold text-white tracking-widest my-1">{previewCode}</div>
                <button
                  type="button"
                  onClick={() => setCode(previewCode)}
                  className="text-[11px] text-emerald-300 underline font-medium hover:text-white"
                >
                  Haz clic para autorrellenar código
                </button>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">Ingresa el PIN de 6 dígitos</label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="000000"
                  className="w-full pl-11 pr-4 py-3 bg-[#141523] border border-white/10 rounded-2xl text-center font-mono text-lg text-white tracking-widest focus:outline-none focus:border-purple-500 transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-purple-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {loading ? 'Verificando...' : 'Ingresar al CRM'}
              <ShieldCheck className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setStep('EMAIL')}
              className="w-full text-xs text-slate-400 hover:text-slate-200 text-center font-medium"
            >
              Cambiar correo electrónico
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
