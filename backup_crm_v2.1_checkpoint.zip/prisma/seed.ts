import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding Outcrop Silver CRM Database...');

  // 1. Clean existing records
  await prisma.relationship.deleteMany();
  await prisma.timelineActivity.deleteMany();
  await prisma.businessCard.deleteMany();
  await prisma.voiceNote.deleteMany();
  await prisma.quote.deleteMany();
  await prisma.deal.deleteMany();
  await prisma.contact.deleteMany();
  await prisma.user.deleteMany();
  await prisma.workflowRule.deleteMany();

  // 2. Create Users
  const admin = await prisma.user.create({
    data: {
      email: 'admin@outcropsilver.com',
      name: 'Nelson Carvajal',
      role: 'Admin',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    },
  });

  const agent1 = await prisma.user.create({
    data: {
      email: 'ir@outcropsilver.com',
      name: 'Sofia Martinez (IR Lead)',
      role: 'IR Manager',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
    },
  });

  // 3. Create Sample Mining & Investor Contacts
  const c1 = await prisma.contact.create({
    data: {
      name: 'Michael Sterling',
      title: 'Managing Director & Portfolio Manager',
      company: 'Apex Precious Metals Fund',
      email: 'm.sterling@apexpmfund.com',
      phone: '+1 416 555 0198',
      whatsapp: '+14165550198',
      location: 'Toronto, Canada',
      bio: 'Institutional PM focused on silver exploration & development in Latin America.',
      investorType: 'Institutional PM',
      stage: 'Interested - committed',
      source: 'Conference',
      leadScore: 85,
    },
  });

  const c2 = await prisma.contact.create({
    data: {
      name: 'Elena Rostova',
      title: 'Senior Mining Analyst',
      company: 'Canaccord Genuity',
      email: 'erostova@canaccord.com',
      phone: '+1 604 555 0142',
      whatsapp: '+16045550142',
      location: 'Vancouver, Canada',
      bio: 'Covers high-grade silver deposits. Published coverage note on Santa Ana project.',
      investorType: 'Institutional analyst',
      stage: 'Interested - shareholder',
      source: 'Analyst referral',
      leadScore: 92,
    },
  });

  const c3 = await prisma.contact.create({
    data: {
      name: 'Dr. Guillermo Gutierrez',
      title: 'Founder & Principal Investor',
      company: 'Andean Capital Family Office',
      email: 'ggutierrez@andeancap.ch',
      phone: '+41 22 555 9811',
      whatsapp: '+41225559811',
      location: 'Geneva, Switzerland',
      bio: 'Family office focused on royalty stream purchases and high-net-worth placements.',
      investorType: 'Family office',
      stage: 'Interested - considering',
      source: 'Brokerage roadshow',
      leadScore: 78,
    },
  });

  const c4 = await prisma.contact.create({
    data: {
      name: 'David Vance',
      title: 'Managing Partner',
      company: 'Sprott Mining Capital',
      email: 'dvance@sprottnet.com',
      phone: '+1 212 555 0321',
      whatsapp: '+12125550321',
      location: 'New York, USA',
      bio: 'HNW & Private equity resource investor with major holdings in silver producers.',
      investorType: 'HNW investor',
      stage: 'Interested - early',
      source: 'Financing',
      leadScore: 65,
    },
  });

  const c5 = await prisma.contact.create({
    data: {
      name: 'Patricia Gomez',
      title: 'VP Business Development',
      company: 'Pan American Silver Corp',
      email: 'pgomez@panamericansilver.com',
      phone: '+1 604 555 8890',
      whatsapp: '+16045558890',
      location: 'Vancouver, Canada',
      bio: 'Corporate strategic partner reviewing M&A and joint venture opportunities.',
      investorType: 'Corporate strategic',
      stage: 'Interested - considering',
      source: 'Networking',
      leadScore: 88,
    },
  });

  // 4. Create Graph Relationships
  await prisma.relationship.createMany({
    data: [
      {
        sourceContactId: c1.id,
        targetContactId: c2.id,
        relationshipType: 'Consulta Análisis de',
        notes: 'Michael confía en la investigación técnica publicada por Elena.',
        strength: 5,
      },
      {
        sourceContactId: c3.id,
        targetContactId: c1.id,
        relationshipType: 'Co-Inversor con',
        notes: 'Co-invirtieron en la ronda de financiamiento Serie B anterior.',
        strength: 4,
      },
      {
        sourceContactId: c4.id,
        targetContactId: c3.id,
        relationshipType: 'Referido por',
        notes: 'Guillermo introdujo a David en la última conferencia PDAC.',
        strength: 4,
      },
      {
        sourceContactId: c5.id,
        targetContactId: c2.id,
        relationshipType: 'Asesor Técnico',
        notes: 'Elena brinda consultoría informal sobre leyes de mineralización de plata.',
        strength: 3,
      },
    ],
  });

  // 5. Create Activities & Timeline
  await prisma.timelineActivity.createMany({
    data: [
      {
        contactId: c1.id,
        type: 'MEETING',
        title: 'Reunión Presencial PDAC 2026',
        description: 'Se presentaron los resultados del programa de perforación de alto tenor en Santa Ana.',
      },
      {
        contactId: c1.id,
        type: 'SCORE_CHANGE',
        title: 'Lead Score Incrementado +15',
        description: 'Score ajustado a 85 por participación en webinar de inversionistas.',
      },
      {
        contactId: c2.id,
        type: 'EMAIL',
        title: 'Envío de Informe Geológico Completo',
        description: 'Se envió el reporte de ensayos de laboratorio con intercepciones de plata > 1000 g/t AgEq.',
      },
    ],
  });

  // 6. Create Deals & Quotes
  const deal1 = await prisma.deal.create({
    data: {
      contactId: c1.id,
      title: 'Colocación Privada Privada - $1.5M CAD',
      amount: 1500000,
      currency: 'CAD',
      stage: 'Proposal',
      probability: 75,
      expectedCloseDate: new Date('2026-09-30'),
    },
  });

  await prisma.quote.create({
    data: {
      contactId: c1.id,
      dealId: deal1.id,
      quoteNumber: 'OUT-2026-0042',
      totalAmount: 1500000,
      status: 'Sent',
      itemsJson: JSON.stringify([
        { description: 'Acciones Ordinarias Outcrop Silver (Unidades a $0.35)', qty: 4285714, unitPrice: 0.35, total: 1500000 },
        { description: 'Warrants de compra de acciones ($0.50 a 24 meses)', qty: 2142857, unitPrice: 0, total: 0 },
      ]),
    },
  });

  // 7. Create Workflow Rules
  await prisma.workflowRule.createMany({
    data: [
      {
        name: 'Alertar IR cuando Lead Score supere 80',
        triggerType: 'LEAD_SCORE_ABOVE',
        triggerValue: '80',
        actionType: 'NOTIFY_TEAM',
        actionValue: 'Enviar notificación urgente a equipo comercial de Outcrop Silver.',
      },
      {
        name: 'Auto-enviar Deck Presentación al cambiar a Interested - committed',
        triggerType: 'STAGE_CHANGED',
        triggerValue: 'Interested - committed',
        actionType: 'SEND_WHATSAPP',
        actionValue: 'Hola {name}, adjuntamos la presentación corporativa y términos del proyecto Santa Ana.',
      },
    ],
  });

  console.log('Outcrop Silver CRM Database successfully seeded!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
